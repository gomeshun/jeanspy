"""JAX/NumPyro model backend.

This module is a supported, functional API for JAX-compatible Jeans
calculations and NumPyro inference. Model parameters are passed explicitly to
calculation methods; the classical, stateful API remains in
:mod:`jeanspy.model`.
"""

from __future__ import annotations

from functools import lru_cache, partial
import operator
from typing import Any, Dict, Mapping, Optional, cast

# IMPORTANT: these env vars must be set before importing JAX.
import os
import warnings

from ._jax_env import configure_jax_environment
from ._zhao import enclosed_mass as _zhao_mass, valid_domain as _zhao_valid

configure_jax_environment()

import jax
import jax.numpy as jnp
import jax.scipy.special as jsp
import numpy as np

# Optional logger (used by callers/tests; kept lightweight)
import logging

logger = logging.getLogger(__name__)


DEFAULT_CONSTANT_KERNEL_BACKEND = "jax"
DEFAULT_SIGMALOS2_BACKEND = "auto"
DEFAULT_SIGMALOS2_JIT = True
DEFAULT_SIGMALOS2_KERNEL_OUTER_TRANSFORM = "sqrtlog"
DEFAULT_BAES_KERNEL_N_QUAD = 32
BAES_ETA_RECOMMENDED_MAX = 10.0


def _prefers_gpu_x32() -> bool:
    return jax.default_backend() == "gpu" and (
        not bool(jax.config.read("jax_enable_x64"))
    )


def _default_constant_kernel_n_quad() -> int:
    return 64 if _prefers_gpu_x32() else 32


def _default_sigmalos2_n_u() -> int:
    return 1024 if _prefers_gpu_x32() else 128


def _default_sigmalos2_n_r() -> int:
    return 768


def _default_sigmalos2_u_max() -> float:
    return 1.0e4


def _normalize_constant_kernel_backend(backend: str) -> str:
    backend_key = str(backend).strip().lower()
    if backend_key not in {"scipy", "jax"}:
        raise ValueError("constant_kernel_backend must be 'scipy' or 'jax'")
    return backend_key


def _normalize_kernel_outer_transform(transform: str) -> str:
    key = str(transform).strip().lower()
    aliases = {
        "sqrtlog": "sqrtlog",
        "sqrt-log": "sqrtlog",
        "sqrt_log": "sqrtlog",
        "log": "log",
    }
    try:
        return aliases[key]
    except KeyError as exc:
        raise ValueError(
            "kernel_outer_transform must be 'sqrtlog' or 'log', "
            f"got {transform!r}"
        ) from exc


def _resolve_n_kernel(n_kernel: Optional[int], *, default: int) -> int:
    resolved = default if n_kernel is None else int(n_kernel)
    if resolved < 8:
        raise ValueError("n_kernel must be >= 8")
    return resolved


def _warn_if_baes_eta_large(eta: Any) -> None:
    """Warn for concrete BAES eta values beyond the well-tested analysis range.

    Hayashi-style dSph analyses typically use eta <= 10.  Traced JAX values
    are intentionally ignored here so a warning callback is never inserted
    into an MCMC hot path.
    """
    from jax import core

    if isinstance(eta, core.Tracer):
        return
    try:
        eta_arr = np.asarray(eta)
    except (TypeError, ValueError):
        return
    if eta_arr.size and np.any(eta_arr > BAES_ETA_RECOMMENDED_MAX):
        warnings.warn(
            "Baes-van Hese eta > 10 is outside the range commonly used in "
            "recent dSph analyses and is less thoroughly validated numerically; "
            "consider increasing n_kernel and checking convergence.",
            RuntimeWarning,
            stacklevel=3,
        )


def get_runtime_config() -> Dict[str, Any]:
    r"""Return the current model_numpyro runtime configuration.

    Notes
    -----
    - Device selection is controlled by JAX itself and must be requested before
      importing JAX. This helper reports both the requested and active backend.
    - Precision can be toggled at runtime through ``configure_runtime`` for
      future traces/compilations.
    - Numerical integration choices are per-call options on ``sigmalos2`` and
      ``ConstantAnisotropyModel.kernel`` rather than process-wide settings.

    **Inputs and units.** ``configure_runtime`` accepts ``jax_enable_x64``;
    ``get_runtime_config`` takes no arguments. Device selection should be set
    through environment variables before JAX initialization.

    **Returns and shape.** Dictionary of effective runtime settings and
    numerical defaults.

    **Validity.** Changing precision after tracing can create a different
    numerical analysis and restart identity.

    **Errors.** Unsupported legacy options are rejected rather than silently
    changing device behavior.

    **Backend.** Host configuration of JAX.

    **Differentiation.** Configuration choices are static, not differentiable.

    **Examples.** ``examples/docs_jax_spherical.py``
    """
    return {
        "jax_platform_requested": os.environ.get(
            "JEANSPY_JAX_PLATFORM", os.environ.get("JAX_PLATFORMS", "")
        ),
        "jax_platform_effective_env": os.environ.get("JAX_PLATFORMS", ""),
        "jax_backend_active": jax.default_backend(),
        "jax_enable_x64": bool(jax.config.read("jax_enable_x64")),
        "constant_kernel_backend_default": DEFAULT_CONSTANT_KERNEL_BACKEND,
        "constant_kernel_n_quad_default": _default_constant_kernel_n_quad(),
        "sigmalos2_backend_default": DEFAULT_SIGMALOS2_BACKEND,
        "sigmalos2_jit_default": DEFAULT_SIGMALOS2_JIT,
        "sigmalos2_kernel_outer_transform_default": DEFAULT_SIGMALOS2_KERNEL_OUTER_TRANSFORM,
        "baes_kernel_n_quad_default": DEFAULT_BAES_KERNEL_N_QUAD,
        "baes_eta_recommended_max": BAES_ETA_RECOMMENDED_MAX,
        "sigmalos2_n_u_default": _default_sigmalos2_n_u(),
        "sigmalos2_n_r_default": _default_sigmalos2_n_r(),
        "sigmalos2_u_max_default": _default_sigmalos2_u_max(),
    }


def configure_runtime(
    *,
    jax_enable_x64: Optional[bool] = None,
    **legacy_kwargs: Any,
) -> Dict[str, Any]:
    r"""Update global runtime knobs used by model_numpyro.

    Only JAX precision remains process-wide. Numerical integration choices are
    passed per call to ``DSphModel.sigmalos2`` or
    ``ConstantAnisotropyModel.kernel``.

    Notes
    -----
    **Inputs and units.** ``configure_runtime`` accepts ``jax_enable_x64``;
    ``get_runtime_config`` takes no arguments. Device selection should be set
    through environment variables before JAX initialization.

    **Returns and shape.** Dictionary of effective runtime settings and
    numerical defaults.

    **Validity.** Changing precision after tracing can create a different
    numerical analysis and restart identity.

    **Errors.** Unsupported legacy options are rejected rather than silently
    changing device behavior.

    **Backend.** Host configuration of JAX.

    **Differentiation.** Configuration choices are static, not differentiable.

    **Examples.** ``examples/docs_jax_spherical.py``
    """
    if legacy_kwargs:
        unsupported = ", ".join(sorted(legacy_kwargs))
        raise TypeError(
            "Numerical runtime options are now per-call arguments. "
            "Pass backend/n_kernel to ConstantAnisotropyModel.kernel() and "
            "backend/jit/n_u/n_r/u_max/kernel_outer_transform/"
            "constant_kernel_backend/n_kernel to DSphModel.sigmalos2(). "
            f"Unsupported configure_runtime keys: {unsupported}."
        )

    if jax_enable_x64 is not None:
        jax.config.update("jax_enable_x64", bool(jax_enable_x64))

    return get_runtime_config()


def _hyp2f1_1_b_3half_scipy(z: jnp.ndarray, b: jnp.ndarray) -> jnp.ndarray:
    """Compute hyp2f1(1, b; 3/2; z) using SciPy via jax.pure_callback.

    Rationale:
    - jax.scipy.special.hyp2f1 can be inaccurate/unstable for some parameter
        regimes relevant to Jeans kernels.
    - Our default MCMC for these models is gradient-free (AIES), so a host
        callback is acceptable and more robust.
    """
    import numpy as _np
    from scipy.special import hyp2f1 as _scipy_hyp2f1

    z = jnp.asarray(z)
    b = jnp.asarray(b)

    out_spec = jax.ShapeDtypeStruct(z.shape, z.dtype)

    def _cb(z_np, b_np):
        # b is expected to be scalar in our current usage.
        b_val = float(_np.asarray(b_np).reshape(()))
        z_arr = _np.asarray(z_np)
        return _scipy_hyp2f1(1.0, b_val, 1.5, z_arr).astype(z_arr.dtype, copy=False)

    return jax.pure_callback(_cb, out_spec, z, b, vmap_method="sequential")


def _hyp2f1_1_b_3half_from_u_scipy(u: jnp.ndarray, b: jnp.ndarray) -> jnp.ndarray:
    """Compute hyp2f1(1, b; 3/2; 1-1/u^2) robustly for large u via SciPy callback.

    We compute z=1-1/u^2 in float64 on host to avoid float32 cancellation that
    rounds z to exactly 1 when u is very large.
    """
    import numpy as _np
    from scipy.special import hyp2f1 as _scipy_hyp2f1

    u = jnp.asarray(u)
    b = jnp.asarray(b)
    out_spec = jax.ShapeDtypeStruct(u.shape, u.dtype)

    def _cb(u_np, b_np):
        b_val = float(_np.asarray(b_np).reshape(()))
        u_arr = _np.asarray(u_np, dtype=_np.float64)
        u2 = u_arr * u_arr
        z_arr = 1.0 - 1.0 / u2
        z_arr = _np.clip(z_arr, 0.0, _np.nextafter(1.0, 0.0))
        return _scipy_hyp2f1(1.0, b_val, 1.5, z_arr).astype(
            _np.asarray(u_np).dtype, copy=False
        )

    return jax.pure_callback(_cb, out_spec, u, b, vmap_method="sequential")


@partial(jax.jit, static_argnames=("n_terms_regular",))
def _hyp2f1_1_b_3half_asymptotic_from_u(
    u: jnp.ndarray,
    b: jnp.ndarray,
    *,
    n_terms_regular: int = 20,
    b_half_tol: float = 1e-6,
) -> jnp.ndarray:
    """Asymptotic 2F1(1,b;3/2;1-1/u^2) evaluated from u directly."""
    u_arr = jnp.asarray(u)
    b_arr = jnp.asarray(b)
    dtype = jnp.result_type(u_arr, b_arr)
    u_arr = u_arr.astype(dtype)
    b_arr = b_arr.astype(dtype)

    one = jnp.asarray(1.0, dtype=dtype)
    half = jnp.asarray(0.5, dtype=dtype)
    two = jnp.asarray(2.0, dtype=dtype)
    finfo = jnp.finfo(dtype)
    tiny = jnp.asarray(finfo.tiny, dtype=dtype)
    eps = jnp.asarray(finfo.eps, dtype=dtype)

    u_safe = jnp.maximum(u_arr, one + eps)
    delta = jnp.clip(one / (u_safe * u_safe), tiny, one - eps)
    sqrt_w = jnp.sqrt(one - delta)

    # b=1/2 exact branch with stable computation of (1-sqrt_w).
    one_minus_sqrt_w = delta / (one + sqrt_w)
    val_b_half = half * (jnp.log1p(sqrt_w) - jnp.log(one_minus_sqrt_w)) / sqrt_w
    is_b_half = jnp.abs(b_arr - half) <= jnp.asarray(b_half_tol, dtype=dtype)

    b_safe = jnp.where(is_b_half, b_arr + jnp.asarray(b_half_tol, dtype=dtype), b_arr)

    # Regular factor: 2F1(1,b;b+1/2;delta)
    term = jnp.ones_like(delta, dtype=dtype)
    regular_factor = term
    n_reg = max(int(n_terms_regular), 1)
    for i in range(n_reg - 1):
        i_f = jnp.asarray(i, dtype=dtype)
        term = term * (b_safe + i_f) / (b_safe + half + i_f) * delta
        regular_factor = regular_factor + term

    a_const = one / (one - two * b_safe)
    regular_term = a_const * regular_factor

    log_b_const = (
        jsp.gammaln(jnp.asarray(1.5, dtype=dtype))
        + jsp.gammaln(b_safe - half)
        - jsp.gammaln(b_safe)
    )
    b_const_sign = jsp.gammasgn(b_safe - half) * jsp.gammasgn(b_safe)
    singular_term = (
        b_const_sign * jnp.exp(log_b_const + (half - b_safe) * jnp.log(delta)) / sqrt_w
    )

    val_general = regular_term + singular_term
    return jnp.asarray(jnp.where(is_b_half, val_b_half, val_general), dtype=dtype)


@partial(jax.jit, static_argnames=("n_kernel",))
def _constant_kernel_jax_backend(
    u: jnp.ndarray,
    beta_ani: jnp.ndarray,
    *,
    n_kernel: int,
) -> jnp.ndarray:
    """Fast JAX-path constant-anisotropy kernel.

    This evaluates the kernel integral directly in ``s = arccosh(u_int)``:

        K(u) = f(uR)/u * integral_0^{arccosh(u)} ds
               cosh(s) * (1 - beta/cosh(s)^2) / f(R cosh(s))

    with ``f(r) = r^(2 beta)`` for constant anisotropy. The direct quadrature
    is more robust than routing through ``hyp2f1`` near continuation poles and
    remains fully JAX/JIT compatible.
    """
    u_arr = jnp.asarray(u)
    dtype = jnp.result_type(u_arr, beta_ani)
    one = jnp.asarray(1.0, dtype=dtype)
    eps = jnp.asarray(jnp.finfo(dtype).eps, dtype=dtype)

    beta = jnp.asarray(beta_ani, dtype=dtype)
    u_in = u_arr.astype(dtype)
    u_safe = jnp.maximum(u_in, one + eps)
    s_max = jnp.arccosh(u_safe)

    n_nodes = max(int(n_kernel), 8)
    t01, w01 = _gauss_legendre_01(n_nodes)
    t01 = jnp.asarray(t01, dtype=dtype)
    w01 = jnp.asarray(w01, dtype=dtype)

    s = s_max[..., None] * t01[None, ...]
    u_int = jnp.cosh(s)
    log_ratio = jnp.clip(
        2.0 * beta * (jnp.log(u_safe)[..., None] - jnp.log(u_int)), min=-80.0, max=80.0
    )
    integrand = u_int * (one - beta / (u_int * u_int)) * jnp.exp(log_ratio)
    weights = s_max[..., None] * w01[None, ...]
    kernel_val = jnp.sum(weights * integrand, axis=-1) / u_safe

    kernel_val = jnp.where(u_in <= one, jnp.zeros_like(kernel_val), kernel_val)
    return kernel_val


@jax.jit
def _osipkov_kernel_jax_backend(
    u: jnp.ndarray, r_pc: jnp.ndarray, r_a: jnp.ndarray
) -> jnp.ndarray:
    """Fast JAX-path Osipkov-Merritt kernel."""
    u_arr, r_arr = jnp.broadcast_arrays(jnp.asarray(u), jnp.asarray(r_pc))
    dtype = jnp.result_type(u_arr, r_arr, r_a)
    one = jnp.asarray(1.0, dtype=dtype)
    eps = jnp.asarray(jnp.finfo(dtype).eps, dtype=dtype)

    u_in = u_arr.astype(dtype)
    u_safe = jnp.maximum(u_in, one + eps)
    r_safe = r_arr.astype(dtype)
    r_a_safe = jnp.asarray(r_a, dtype=dtype)

    u_a = r_a_safe / r_safe
    u2_a = u_a**2
    u2 = u_safe**2
    sqrt_term = jnp.sqrt((u2 - 1.0) / (u2_a + 1.0))
    arctan_term = jnp.arctan(sqrt_term)
    sqrt_term2 = jnp.sqrt(1.0 - 1.0 / u2)
    kernel_val = (u2 + u2_a) * (u2_a + 0.5) / (
        u_safe * (u2_a + 1.0) ** 1.5
    ) * arctan_term - sqrt_term2 / (2.0 * (u2_a + 1.0))
    return jnp.where(u_in <= 1.0, jnp.zeros_like(kernel_val), kernel_val)


@partial(jax.jit, static_argnames=("n_kernel",))
def _baes_kernel_jax_backend(
    u: jnp.ndarray,
    r_pc: jnp.ndarray,
    beta_0: jnp.ndarray,
    beta_inf: jnp.ndarray,
    r_a: jnp.ndarray,
    eta: jnp.ndarray,
    *,
    n_kernel: int,
) -> jnp.ndarray:
    """Fast JAX-path BAES kernel using Gauss-Legendre quadrature in arccosh(u)."""
    u_arr, r_arr = jnp.broadcast_arrays(jnp.asarray(u), jnp.asarray(r_pc))
    dtype = jnp.result_type(u_arr, r_arr, beta_0, beta_inf, r_a, eta)
    one = jnp.asarray(1.0, dtype=dtype)
    eps = jnp.asarray(jnp.finfo(dtype).eps, dtype=dtype)

    u_in = u_arr.astype(dtype)
    u_safe = jnp.maximum(u_in, one + eps)
    tiny = jnp.asarray(jnp.finfo(dtype).tiny, dtype=dtype)
    r_safe = jnp.maximum(r_arr.astype(dtype), tiny)
    beta0 = jnp.asarray(beta_0, dtype=dtype)
    betainf = jnp.asarray(beta_inf, dtype=dtype)
    q = betainf - beta0
    r_a_safe = jnp.maximum(jnp.asarray(r_a, dtype=dtype), tiny)
    eta_safe = jnp.maximum(jnp.asarray(eta, dtype=dtype), tiny)

    same_beta = jnp.reshape(
        jnp.abs(beta0 - betainf) <= jnp.asarray(1e-12, dtype=dtype),
        (),
    )

    def _constant_limit(_: None) -> jnp.ndarray:
        return _constant_kernel_jax_backend(u_in, beta0, n_kernel=n_kernel)

    def _generic(_: None) -> jnp.ndarray:
        s_max = jnp.arccosh(u_safe)
        n_nodes = max(int(n_kernel), 8)
        t01, w01 = _gauss_legendre_01(n_nodes)
        t01 = jnp.asarray(t01, dtype=dtype)
        w01 = jnp.asarray(w01, dtype=dtype)

        s = s_max[..., None] * t01[None, ...]
        u_int = jnp.cosh(s)

        # Work in log(r/r_a).  Directly forming (r/r_a)**eta can overflow
        # in float32 for sharp transitions even while the physical beta(r)
        # and the required f(s)/f(r) ratio remain perfectly finite.
        log_R_over_ra = jnp.log(r_safe / r_a_safe)
        log_rint_over_ra = log_R_over_ra[..., None] + jnp.log(u_int)
        log_rs_over_ra = log_R_over_ra + jnp.log(u_safe)
        ell_int = eta_safe * log_rint_over_ra
        ell_s = eta_safe * log_rs_over_ra

        beta_int = beta0 + q * jax.nn.sigmoid(ell_int)
        log_ratio = (
            2.0 * beta0 * (jnp.log(u_safe)[..., None] - jnp.log(u_int))
            + (2.0 * q / eta_safe)
            * (jax.nn.softplus(ell_s)[..., None] - jax.nn.softplus(ell_int))
        )
        log_ratio = jnp.clip(log_ratio, min=-80.0, max=80.0)
        integ_s = u_int * (1.0 - beta_int / (u_int**2)) * jnp.exp(log_ratio)
        weights = s_max[..., None] * w01[None, ...]
        inner = jnp.sum(weights * integ_s, axis=-1)

        k_val = inner / u_safe
        k_val = jnp.where(u_in <= 1.0, jnp.zeros_like(k_val), k_val)
        return k_val

    return jax.lax.cond(same_beta, _constant_limit, _generic, operand=None)


# Physical constants (floats are fine in JAX computations)
GMsun_m3s2: float = 1.32712440018e20
PARSEC_M: float = 3.085677581491367e16


@lru_cache(maxsize=16)
def _gauss_legendre_01(n: int) -> tuple[np.ndarray, np.ndarray]:
    """Gauss-Legendre nodes/weights mapped to [0,1]."""
    x, w = np.polynomial.legendre.leggauss(int(n))
    t = 0.5 * (x + 1.0)
    wt = 0.5 * w
    return t, wt


def _trapz(y: jnp.ndarray, x: jnp.ndarray, axis: int = -1) -> jnp.ndarray:
    """JAX-friendly trapezoidal integration."""
    dx = jnp.diff(x, axis=axis)
    y0 = jnp.take(y, indices=jnp.arange(y.shape[axis] - 1), axis=axis)
    y1 = jnp.take(y, indices=jnp.arange(1, y.shape[axis]), axis=axis)
    return jnp.sum((y0 + y1) * 0.5 * dx, axis=axis)


def _simpson_uniform_last_axis(y: jnp.ndarray, h: jnp.ndarray) -> jnp.ndarray:
    """Composite Simpson integration on a uniform grid along the last axis.

    If the number of points is even, the final interval falls back to a trapezoid.
    """
    n = int(y.shape[-1])
    if n < 3:
        return jnp.sum((y[..., :-1] + y[..., 1:]) * (0.5 * h), axis=-1)

    if n % 2 == 1:
        return (h / 3.0) * (
            y[..., 0]
            + y[..., -1]
            + 4.0 * jnp.sum(y[..., 1:-1:2], axis=-1)
            + 2.0 * jnp.sum(y[..., 2:-2:2], axis=-1)
        )

    simpson_main = (h / 3.0) * (
        y[..., 0]
        + y[..., -2]
        + 4.0 * jnp.sum(y[..., 1:-2:2], axis=-1)
        + 2.0 * jnp.sum(y[..., 2:-3:2], axis=-1)
    )
    trapezoid_tail = 0.5 * h * (y[..., -2] + y[..., -1])
    return simpson_main + trapezoid_tail


def _nfw_enclosed_mass_shape(x: jnp.ndarray) -> jnp.ndarray:
    """Return log(1+x) - x/(1+x) with a stable small-x series."""
    x_arr = jnp.asarray(x)
    dtype = x_arr.dtype
    direct = jnp.log1p(x_arr) - x_arr / (1.0 + x_arr)
    series = x_arr**2 * (
        0.5
        + x_arr * (-2.0 / 3.0 + x_arr * (0.75 + x_arr * (-0.8 + x_arr * (5.0 / 6.0))))
    )
    threshold = jnp.asarray(1e-3, dtype=dtype)
    return jnp.where(x_arr < threshold, series, direct)


def _reverse_cumtrapz_1d(y: jnp.ndarray, x: jnp.ndarray) -> jnp.ndarray:
    """Return I[i] = integral from x[i] to x[-1] of y(t) dt on a 1D grid."""
    dx = jnp.diff(x)
    seg = 0.5 * (y[:-1] + y[1:]) * dx
    rev = jnp.cumsum(seg[::-1])[::-1]
    return jnp.concatenate([rev, jnp.zeros((1,), dtype=y.dtype)], axis=0)


def _projected_radii(R_pc):
    """JIT-safe positive-radius domain with per-element invalidity.

    Substitute a valid radius only for internal evaluation; invalid inputs
    are restored to NaN in the result. Using the minimum valid radius keeps
    invalid array members from changing the Abel radial grid.
    """
    raw = jnp.asarray(R_pc)
    if raw.ndim > 1 or raw.size == 0:
        raise ValueError("R_pc must be a scalar or nonempty one-dimensional array.")
    R = jnp.atleast_1d(raw).astype(jnp.result_type(raw, 1.0))
    valid = jnp.isfinite(R) & (R > 0)
    smallest = jnp.min(jnp.where(valid, R, jnp.inf))
    replacement = jnp.where(jnp.any(valid), smallest, 1.0)
    return jnp.where(valid, R, replacement), valid


def _make_log_grid(
    r_min: jnp.ndarray, r_max: jnp.ndarray, n_r: int
) -> tuple[jnp.ndarray, jnp.ndarray]:
    """Return log-spaced grid points and matching bin edges."""
    n_r = int(n_r)
    if n_r < 4:
        raise ValueError("n_r must be >= 4")

    x = jnp.linspace(jnp.log(r_min), jnp.log(r_max), n_r)
    dx = x[1] - x[0]
    x_edges = jnp.concatenate(
        [x[:1] - 0.5 * dx, 0.5 * (x[:-1] + x[1:]), x[-1:] + 0.5 * dx],
        axis=0,
    )
    return jnp.exp(x), jnp.exp(x_edges)


# cache for abel weights keyed by flattened R and edge arrays
_abel_weights_cache: Dict[tuple, jnp.ndarray] = {}


def _abel_bin_weights(R_flat, r_edges):
    """Exact bin weights without evaluating acosh at a clipped endpoint.

    acosh'(1) is infinite. Evaluating it in an inactive jnp.where branch
    poisons reverse-mode derivatives with 0*inf, even for positive R.
    """
    R = R_flat[:, None]
    lo, hi = r_edges[:-1][None, :], r_edges[1:][None, :]
    above_lo, above_hi = lo > R, hi > R
    lo_ratio = jnp.where(above_lo, lo / R, 2.0)
    hi_ratio = jnp.where(above_hi, hi / R, 2.0)
    lower = jnp.where(above_lo, jnp.arccosh(lo_ratio), 0.0)
    upper = jnp.where(above_hi, jnp.arccosh(hi_ratio), 0.0)
    return upper - lower


def _abel_weights(R_pc: jnp.ndarray, r_edges_pc: jnp.ndarray) -> jnp.ndarray:
    """Return weight matrix for a given set of projected radii and radial edges.

    The result has shape ``(R_flat.size, r_edges_pc.size-1)`` and is cached on the
    Python side so that repeated calls with the same geometry are cheap.  The
    cache key is built from the raw bytes of the flattened arrays along with
    their shapes and dtypes to avoid collisions.
    """
    # ensure we work with a flat 1‑D view of R for caching/reshaping
    # If we are being traced under jax.jit, the R_pc/r_edges_pc arguments will
    # be Tracer objects and we cannot convert them to bytes to form a cache key.
    # In that case we simply compute the weights on the fly without caching; the
    # JIT compiler will hoist and optimise any repeated arithmetic.
    from jax import core

    # ensure we work with a flat 1‑D view of R for caching/reshaping
    R_arr = jnp.atleast_1d(jnp.asarray(R_pc))
    R_flat = R_arr.ravel()
    r_edges = jnp.asarray(r_edges_pc)

    if isinstance(R_flat, core.Tracer) or isinstance(r_edges, core.Tracer):
        return _abel_bin_weights(R_flat, r_edges)

    key = (
        R_flat.shape,
        R_flat.dtype,
        bytes(R_flat.tobytes()),
        r_edges.shape,
        r_edges.dtype,
        bytes(r_edges.tobytes()),
    )
    if key in _abel_weights_cache:
        return _abel_weights_cache[key]

    weights = _abel_bin_weights(R_flat, r_edges)
    _abel_weights_cache[key] = weights
    return weights


def _abel_transform_piecewise_constant(
    g_r: jnp.ndarray,
    R_pc: jnp.ndarray,
    r_edges_pc: jnp.ndarray,
) -> jnp.ndarray:
    r"""Compute A[g](R)=integral_R^inf g(r)/sqrt(r^2-R^2) dr with exact bin weights.

    The helper now supports arbitrarily-shaped ``R_pc`` arrays by flattening
    before the transform and reshaping the result back to the original shape.
    Weight matrices are cached via ``_abel_weights`` so that multiple calls with
    the same projection geometry (e.g. fixed R grid) are very cheap.
    """
    R_arr = jnp.atleast_1d(jnp.asarray(R_pc))
    orig_shape = R_arr.shape
    R_flat = R_arr.ravel()
    g = jnp.asarray(g_r)

    weights = _abel_weights(R_flat, jnp.asarray(r_edges_pc))
    result_flat = jnp.sum(weights * g[None, :], axis=-1)
    return result_flat.reshape(orig_shape)


class Model:
    r"""Minimal model container designed to work well with NumPyro.

    Design goals:
    - Keep parameter grouping + submodel composition (like the existing model.py)
    - Avoid pandas/scipy and keep computations JAX-friendly
    - Keep side effects minimal: prefer passing params explicitly in numpyro models

    Notes:
    - This base class intentionally implements only what is needed for MCMC demos/tests.

    Notes
    -----
    **Inputs and units.** submodels maps the exact role names declared by the
    concrete class; no physical values are stored here. Numerical methods
    receive explicit parameters.

    **Returns and shape.** A component container with __getitem__ role access
    and ``sampling_identity`` without JIT cache.

    **Validity.** Physical parameter dictionaries hold scalar values; radius
    arrays are broadcast independently. Use vmap to batch parameter
    dictionaries.

    **Errors.** Missing/extra submodel roles raise ValueError.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Composition is static; differentiation applies to
    array-valued numerical method arguments.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    # Kept as metadata only; NumPyro models typically pass params explicitly.
    required_param_names: tuple[str, ...] = ()
    required_models: Mapping[str, type["Model"]] = {}

    def __init__(self, submodels: Optional[Mapping[str, "Model"]] = None):
        if submodels is None:
            submodels = {}

        # Validate required submodels
        expected = set(getattr(self, "required_models", {}).keys())
        provided = set(submodels.keys())
        if expected != provided:
            raise ValueError(
                f"{self.__class__.__name__} requires submodels {sorted(expected)} "
                f"but got {sorted(provided)}"
            )
        self.submodels: Dict[str, Model] = dict(submodels)
        self._jit_cache: Dict[tuple[Any, ...], Any] = {}

    def __getitem__(self, key: str) -> "Model":
        return self.submodels[key]

    def sampling_identity(self):
        """Model configuration without the derived compilation cache."""
        return {k: v for k, v in vars(self).items() if k != "_jit_cache"}


class StellarModel(Model):
    required_models: Mapping[str, type[Model]] = {}

    def density_2d(self, R_pc: jnp.ndarray, *, re_pc: Any) -> jnp.ndarray:
        raise NotImplementedError

    def density_3d(self, r_pc: jnp.ndarray, *, re_pc: Any) -> jnp.ndarray:
        raise NotImplementedError


class PlummerModel(StellarModel):
    r"""Plummer surface/volume density normalized so that \int 2πR Σ(R) dR = 1.

    Notes
    -----
    **Inputs and units.** ``density_2d(R_pc, re_pc=...)`` and
    ``density_3d(r_pc, re_pc=...)`` use pc.
    ``sample_R(key, n, re_pc=...)`` takes a JAX random key and static sample
    count.

    **Returns and shape.** pc^-2 or pc^-3 density with broadcast input shape;
    ``log_prob_R`` includes 2\*pi\*R and is the log radial PDF; ``sample_R``
    returns shape (n,) radii in pc.

    **Validity.** Positive ``re_pc``, nonnegative radius; ``log_prob_R`` is
    minus infinity outside its support.

    **Errors.** Low-level density expressions can produce NaN/inf for invalid
    parameters.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Physical scales and valid radii are differentiable;
    random keys and sample counts are not.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    required_param_names = ("re_pc",)

    def density_2d(self, R_pc: jnp.ndarray, *, re_pc: Any) -> jnp.ndarray:
        """Return unit-normalized Plummer surface density in pc^-2 on JAX.

        ``R_pc`` is a projected scalar/array radius in pc and ``re_pc`` is the
        positive projected half-light scale in pc. Output follows broadcasting;
        the expression is differentiable within the valid domain. This elementary
        helper does not validate physical parameter values.
        """
        re = jnp.asarray(re_pc)
        x2 = (R_pc / re) ** 2
        return 1.0 / (jnp.pi * re**2) * (1.0 + x2) ** (-2.0)

    def density_3d(self, r_pc: jnp.ndarray, *, re_pc: Any) -> jnp.ndarray:
        """Return unit-normalized Plummer density in pc^-3 on the JAX backend.

        ``r_pc`` is an intrinsic scalar/array radius in pc and ``re_pc`` is the
        positive projected half-light scale in pc. Output follows broadcasting;
        the expression is differentiable within the valid domain. This elementary
        helper does not validate physical parameter values.
        """
        re = jnp.asarray(re_pc)
        x2 = (r_pc / re) ** 2
        return (3.0 / (4.0 * jnp.pi * re**3)) * (1.0 + x2) ** (-2.5)

    def log_prob_R(self, R_pc: jnp.ndarray, *, re_pc: Any) -> jnp.ndarray:
        r"""Log-pdf of observed projected radius R (i.e. p(R) dR).

        p(R) = 2πR Σ(R) = 2R/re^2 * (1 + (R/re)^2)^(-2)

        Notes
        -----
        **Inputs and units.** ``R_pc`` and positive ``re_pc`` in pc, broadcastable.

        **Returns and shape.** Natural log radial PDF including 2\*pi\*R, with
        broadcast shape; minus infinity off support.
        """
        re = jnp.asarray(re_pc)
        R = jnp.asarray(R_pc)
        x2 = (R / re) ** 2
        logp = jnp.log(2.0) + jnp.log(R) - 2.0 * jnp.log(re) - 2.0 * jnp.log1p(x2)
        return logp

    def sample_R(self, key: jax.Array, n: int, *, re_pc: Any) -> jnp.ndarray:
        r"""Sample projected radii using the analytic inverse CDF.

        CDF(R) = R^2 / (R^2 + re^2)  ->  R = re * sqrt(u/(1-u)).

        Notes
        -----
        **Inputs and units.** key is a JAX random key; n is a static nonnegative
        count; ``re_pc`` is positive scale in pc.

        **Returns and shape.** Array (n,) of radii in pc. Split keys explicitly
        before repeated independent draws.
        """
        u = jax.random.uniform(key, shape=(n,), minval=0.0, maxval=1.0)
        u = jnp.clip(u, 1e-12, 1.0 - 1e-12)
        re = jnp.asarray(re_pc)
        return re * jnp.sqrt(u / (1.0 - u))


class DMModel(Model):
    required_models: Mapping[str, type[Model]] = {}
    analytic_enclosed_mass_autodiff_safe = False

    def resolve_params(self, params: Mapping[str, Any]) -> Mapping[str, Any]:
        """Return the physical parameter mapping unchanged for the generic halo.

        Subclasses may add reusable mass coefficients. This base hook performs
        no validation or copying.
        """
        return params

    def mass_density_3d(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        raise NotImplementedError

    def enclosed_mass_analytic(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        raise NotImplementedError

    def enclosed_mass_numeric(
        self,
        r_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        n_steps: int = 256,
        t_min: float = 1e-6,
    ) -> jnp.ndarray:
        r"""Numerically compute enclosed mass via 4π∫ρ(r)r²dr.

        This default path is AD-friendly and avoids special-function gradient issues.
        If `r_t_pc` exists in `params`, radius is truncated at that value.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        if operator.index(n_steps) < 2:
            raise ValueError("n_steps must be an integer >= 2")
        if not np.isfinite(t_min) or not 0 < t_min < 1:
            raise ValueError("t_min must be finite and strictly between 0 and 1")
        dtype = jnp.result_type(jnp.asarray(r_pc), *(jnp.asarray(params[k]) for k in self.required_param_names), 1.0)
        r = jnp.asarray(r_pc, dtype=dtype)
        valid = self.valid_mass_domain(r, params=params)
        if "r_t_pc" in params:
            r_t = jnp.asarray(params["r_t_pc"], dtype=dtype)
            r = jnp.minimum(r, r_t)

        # Evaluate zero/invalid radii at a finite placeholder to avoid 0 * inf
        # at a central cusp. Only valid zero radii are mapped to zero mass.
        r_pos = jnp.where(valid & (r > 0), r, 1.0)
        t = jnp.linspace(
            jnp.asarray(t_min, dtype=dtype), jnp.asarray(1.0, dtype=dtype), int(n_steps)
        )

        r_grid = r_pos[..., None] * t
        rho = self.mass_density_3d(r_grid, params=params)
        integrand_t = 4.0 * jnp.pi * (r_grid**2) * rho * r_pos[..., None]
        mass = _trapz(integrand_t, t, axis=-1)
        valid = valid & jnp.all(jnp.isfinite(rho) & (rho >= 0), axis=-1)
        return jnp.where(valid, jnp.where(r == 0, 0.0, mass), jnp.nan)

    def valid_mass_domain(self, r_pc, *, params):
        """Dynamic validity mask; custom profiles may impose stricter domains."""
        r = jnp.asarray(r_pc)
        valid = (r >= 0) & ~jnp.isnan(r)
        for name in self.required_param_names:
            value = jnp.asarray(params[name])
            if name == "r_t_pc":
                valid = valid & (value > 0) & ~jnp.isnan(value)
            else:
                valid = valid & jnp.isfinite(value)
            if name in ("rs_pc", "rhos_Msunpc3"):
                valid = valid & (value > 0)
        return valid & jnp.isfinite(jnp.minimum(r, params.get("r_t_pc", jnp.inf)))

    @property
    def has_analytic_enclosed_mass(self) -> bool:
        """Whether this halo exposes a callable analytic enclosed-mass implementation."""
        return hasattr(self, "enclosed_mass_analytic") and callable(
            getattr(self, "enclosed_mass_analytic")
        )

    def enclosed_mass(
        self, r_pc: jnp.ndarray, method: str = "auto", *, params: Mapping[str, Any],
        n_steps: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""Return enclosed mass with selectable backend.

        The default ``auto`` method uses each model's autodiff-safe default:
        analytic for NFW and numeric for Zhao. Pass ``method="analytic"`` to
        request a closed form explicitly, or ``method="numeric"`` for the
        autodiff-friendly numerical integral.

        ``n_steps`` sets numerical mass resolution (Zhao: Gauss nodes per
        segment). None uses the model default; analytic methods ignore it.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        method_key = str(method).strip().lower()
        if method_key == "auto":
            resolved_method = (
                "analytic"
                if (
                    bool(self.analytic_enclosed_mass_autodiff_safe)
                    and self.has_analytic_enclosed_mass
                )
                else "numeric"
            )
        else:
            resolved_method = method_key
        has_analytic = self.has_analytic_enclosed_mass
        if resolved_method == "analytic":
            if has_analytic:
                return self.enclosed_mass_analytic(r_pc, params=params)
            else:
                raise NotImplementedError(
                    f"{self.__class__.__name__} does not have an analytic enclosed_mass implementation"
                )
        elif resolved_method == "numeric":
            numeric_kwargs = {} if n_steps is None else {"n_steps": n_steps}
            return self.enclosed_mass_numeric(r_pc, params=params, **numeric_kwargs)
        else:
            raise ValueError(
                f"method must be 'analytic', 'numeric', or 'auto', got {method!r}"
            )

    def enclosure_mass(
        self, r_pc: jnp.ndarray, method: str = "auto", *, params: Mapping[str, Any],
        n_steps: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""Compatibility spelling shared with the classical backend.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        return self.enclosed_mass(r_pc, method=method, params=params, n_steps=n_steps)


class NFWModel(DMModel):
    r"""Functional spherical halo density and mass.

    Notes
    -----
    **Inputs and units.** params contains ``rs_pc``, ``rhos_Msunpc3`` and
    ``r_t_pc``; Zhao also needs a,b,g. NFW ``resolve_params`` derives and
    returns the mass normalization from these scale parameters. ``r_pc`` is
    nonnegative pc; method is auto/analytic/numeric; ``n_steps`` is a static
    mass quadrature order.

    **Returns and shape.** Density Msun/pc^3; mass Msun within
    ``min(r_pc, r_t_pc)``, matching radius shape. ``enclosure_mass`` is an
    alias; ``valid_mass_domain`` returns a Boolean mask. Classical/JAX density
    methods themselves evaluate the untruncated profile.

    **Validity.** Positive scales/cutoff; Zhao a>0 and g<3. Finite-radius mass
    allows b<=3. Analytic NFW has a stable small-radius expression.

    **Errors.** Invalid physical mass proposals yield NaN. Unsupported
    mass-method names raise ValueError.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** auto chooses analytic NFW and cusp-regularized numeric
    Zhao. Zhao ``enclosed_mass_betainc``/analytic does not support autodiff in
    shape parameters; use auto/numeric for that purpose. Hard-cutoff boundaries
    need separate treatment.

    **Examples.** ``examples/docs_jax_spherical.py``
    """
    required_param_names = ("rs_pc", "rhos_Msunpc3", "r_t_pc")
    analytic_enclosed_mass_autodiff_safe = True

    def resolve_params(self, params: Mapping[str, Any]) -> dict[str, jnp.ndarray]:
        """Resolve NFW scales and cache their mass coefficient as JAX arrays.

        Requires rs_pc and r_t_pc in pc, and rhos_Msunpc3 in Msun/pc^3; a missing
        key raises KeyError. Returns those entries and nfw_mass_coeff in Msun.
        Continuous expressions are differentiable; physical-domain validation
        is performed by the mass/likelihood paths that consume them.
        """
        rs = jnp.asarray(params["rs_pc"])
        rhos = jnp.asarray(params["rhos_Msunpc3"])
        r_t = jnp.asarray(params["r_t_pc"])
        coeff = 4.0 * jnp.pi * rhos * rs**3
        return {
            "rs_pc": rs,
            "rhos_Msunpc3": rhos,
            "r_t_pc": r_t,
            "nfw_mass_coeff": coeff,
        }

    def mass_density_3d(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Evaluate functional spherical halo density.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is a physical
        scalar dictionary.

        **Returns and shape.** Untruncated density in Msun/pc^3 with radius shape.
        """
        resolved = self.resolve_params(params)
        rs = jnp.asarray(resolved["rs_pc"])
        rhos = jnp.asarray(resolved["rhos_Msunpc3"])
        r = jnp.asarray(r_pc)
        x = r / rs
        return rhos / x / (1.0 + x) ** 2

    def enclosed_mass_analytic(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Evaluate functional spherical halo mass.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        resolved = self.resolve_params(params)
        rs = jnp.asarray(resolved["rs_pc"])
        r_t = jnp.asarray(resolved["r_t_pc"])

        r = jnp.minimum(jnp.asarray(r_pc), r_t)
        x = r / rs
        # M(r) = 4π ρs rs^3 [ ln(1+x) - x/(1+x) ]
        coeff = jnp.asarray(resolved["nfw_mass_coeff"])
        mass = coeff * _nfw_enclosed_mass_shape(x)
        return jnp.where(self.valid_mass_domain(r_pc, params=params), mass, jnp.nan)


class ZhaoModel(DMModel):
    r"""Functional spherical halo density and mass.

    Notes
    -----
    **Inputs and units.** params contains ``rs_pc``, ``rhos_Msunpc3`` and
    ``r_t_pc``; Zhao also needs a,b,g. NFW ``resolve_params`` derives and
    returns the mass normalization from these scale parameters. ``r_pc`` is
    nonnegative pc; method is auto/analytic/numeric; ``n_steps`` is a static
    mass quadrature order.

    **Returns and shape.** Density Msun/pc^3; mass Msun within
    ``min(r_pc, r_t_pc)``, matching radius shape. ``enclosure_mass`` is an
    alias; ``valid_mass_domain`` returns a Boolean mask. Classical/JAX density
    methods themselves evaluate the untruncated profile.

    **Validity.** Positive scales/cutoff; Zhao a>0 and g<3. Finite-radius mass
    allows b<=3. Analytic NFW has a stable small-radius expression.

    **Errors.** Invalid physical mass proposals yield NaN. Unsupported
    mass-method names raise ValueError.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** auto chooses analytic NFW and cusp-regularized numeric
    Zhao. Zhao ``enclosed_mass_betainc``/analytic does not support autodiff in
    shape parameters; use auto/numeric for that purpose. Hard-cutoff boundaries
    need separate treatment.

    **Examples.** ``examples/docs_jax_spherical.py``
    """
    required_param_names = ("rs_pc", "rhos_Msunpc3", "a", "b", "g", "r_t_pc")
    analytic_enclosed_mass_autodiff_safe = False

    def mass_density_3d(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Evaluate functional spherical halo density.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is a physical
        scalar dictionary.

        **Returns and shape.** Untruncated density in Msun/pc^3 with radius shape.
        """
        rs = jnp.asarray(params["rs_pc"])
        rhos = jnp.asarray(params["rhos_Msunpc3"])
        a_arr = jnp.asarray(params["a"])
        b_arr = jnp.asarray(params["b"])
        g_arr = jnp.asarray(params["g"])
        r = jnp.asarray(r_pc)
        x = r / rs
        return rhos * x ** (-g_arr) * (1.0 + x**a_arr) ** (-(b_arr - g_arr) / a_arr)

    def enclosed_mass_numeric(self, r_pc, *, params, n_steps=128):
        r"""Cusp-regularized, differentiable quadrature without a central cutoff.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        return _zhao_mass(r_pc, params, xp=jnp, n_steps=n_steps)

    def enclosed_mass_betainc(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        """Enclosed mass from the Zhao incomplete-beta closed form.

        For b <= 3 (outside the beta domain), or a saturated beta argument,
        use the regularized numerical integral. Shape autodiff is unsupported
        on this explicit analytic path; use auto/numeric for inference.

        The NFW-limit branch ``(a,b,g)=(1,3,1)`` is handled analytically because
        the raw beta/betainc expression becomes indeterminate there even though
        the physical enclosed mass remains finite.
        """
        rs = jnp.asarray(params["rs_pc"])
        rhos = jnp.asarray(params["rhos_Msunpc3"])
        r_t = jnp.asarray(params["r_t_pc"])
        a_arr = jnp.asarray(params["a"])
        b_arr = jnp.asarray(params["b"])
        g_arr = jnp.asarray(params["g"])

        r = jnp.minimum(jnp.asarray(r_pc), r_t)
        x_raw = r / rs
        x = x_raw**a_arr

        argbeta0 = (3.0 - g_arr) / a_arr
        argbeta1 = (b_arr - 3.0) / a_arr
        z = x / (1.0 + x)

        tol = jnp.asarray(1e-7, dtype=jnp.result_type(a_arr, b_arr, g_arr))
        is_nfw_limit = (
            (jnp.abs(a_arr - 1.0) <= tol)
            & (jnp.abs(b_arr - 3.0) <= tol)
            & (jnp.abs(g_arr - 1.0) <= tol)
        )
        argbeta1_safe = jnp.where(
            argbeta1 <= 0, jnp.asarray(1.0, dtype=argbeta1.dtype), argbeta1
        )
        coeff_general = 4.0 * jnp.pi * rs**3 * rhos / a_arr
        mass_general = (
            coeff_general
            * jsp.beta(argbeta0, argbeta1_safe)
            * jsp.betainc(argbeta0, argbeta1_safe, z)
        )

        coeff_nfw = 4.0 * jnp.pi * rhos * rs**3
        mass_nfw = coeff_nfw * _nfw_enclosed_mass_shape(x_raw)

        # The incomplete-beta domain excludes b <= 3; finite-radius mass does not.
        fallback = self.enclosed_mass_numeric(r_pc, params=params)
        general = jnp.where(
            (argbeta1 > 0) & (z > 0) & (z < 1) & jnp.isfinite(mass_general),
            mass_general,
            fallback,
        )
        mass = jnp.where(is_nfw_limit, mass_nfw, general)
        return jnp.where(_zhao_valid(jnp.asarray(r_pc), params, jnp), mass, jnp.nan)

    def enclosed_mass_analytic(
        self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Evaluate functional spherical halo mass.

        Notes
        -----
        **Inputs and units.** ``r_pc`` is scalar/array in pc; params is the physical
        dictionary. ``enclosed_mass``/``enclosure_mass`` select
        method=auto/analytic/numeric; numerical methods accept ``n_steps``.

        **Returns and shape.** Mass in Msun within ``min(r_pc, r_t_pc)``,
        matching radius shape. Invalid dynamic proposals yield NaN.
        """
        return self.enclosed_mass_betainc(r_pc, params=params)


class AnisotropyModel(Model):
    r"""Base interface for anisotropy models used in Jeans LOS integration.

    The note defines

        f(r) = f(r0) * exp(\int_{r0}^{r} 2 beta(t) / t dt)

    and the projected-dispersion kernel formulation through beta(r), f(r), and K(u).
    Subclasses are expected to implement these quantities consistently.
    """

    required_models: Mapping[str, type[Model]] = {}

    def beta(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Anisotropy profile beta(r) at 3D radius `r_pc`."""
        raise NotImplementedError

    def f(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Auxiliary function f(r) satisfying d ln f / d ln r = 2 beta(r)."""
        raise NotImplementedError

    def kernel(
        self, u: jnp.ndarray, R_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Kernel K(u) entering sigma_los^2(R) = 2 * \int du ... K(u)/u."""
        raise NotImplementedError


class ConstantAnisotropyModel(AnisotropyModel):
    r"""Constant anisotropy model with beta(r) = beta_ani.

    For constant beta,

        f(r) = r^{2 beta_ani}

    and K(u) has a closed form involving Gauss hypergeometric function.

    Notes
    -----
    **Inputs and units.** params follows the corresponding classical profile
    names: ``beta_ani``, or ``r_a``, or ``beta_0``/``beta_inf``/``r_a``/eta.
    Radii in pc and u=r/R dimensionless. kernel backend/order arguments are
    static numerical choices.

    **Returns and shape.** Dimensionless beta/kernel and integrating factor f,
    with broadcast shape.

    **Validity.** Require finite beta<1, positive transition radius/sharpness
    where applicable. Baes large eta needs numerical refinement; the default
    solver chooses Abel for general Baes.

    **Errors.** Invalid static backend/options raise; invalid physical proposals
    can produce NaN. Warnings flag known sharp-transition limitations.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Use the JAX kernel path. The explicit SciPy callback
    route is a reference, not a fully differentiated physical-parameter path.
    Verify gradients near branch and anisotropy limits.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    required_param_names = ("beta_ani",)

    def beta(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Return constant beta_ani with the same shape as `r_pc`."""
        return jnp.asarray(params["beta_ani"]) * jnp.ones_like(r_pc)

    def f(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Return f(r)=r^(2 beta_ani) from the note definition."""
        beta_ani = jnp.asarray(params["beta_ani"])
        r = jnp.asarray(r_pc)
        return r ** (2.0 * beta_ani)

    def kernel(
        self,
        u: jnp.ndarray,
        R_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        backend: str = DEFAULT_CONSTANT_KERNEL_BACKEND,
        n_kernel: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""LOSVD kernel K(u) for constant anisotropy.

        Uses the transformed hypergeometric representation

            K(u) = sqrt(1-u^{-2}) * ((3/2-beta) * 2F1(1,beta;3/2;1-u^{-2}) - 1/2)

        which is algebraically equivalent to the original form in `model.py` and
        numerically stable for large `u`.

        Parameters
        ----------
        u:
            Dimensionless radius ratio u=r/R (typically u>1).
        R_pc:
            Kept for API compatibility; K(u) is independent of R in this model.
        backend:
            ``'jax'`` uses the direct JAX quadrature kernel. ``'scipy'`` uses the
            SciPy hypergeometric formulation.
        n_kernel:
            Quadrature order for the direct JAX kernel backend.
        """
        beta_ani = jnp.asarray(params["beta_ani"])
        backend_key = _normalize_constant_kernel_backend(backend)

        # The original expression (as in model.py) uses
        #   hyp2f1(1, 1.5-beta, 1.5, 1-u^2)
        # where (1-u^2) can be a large negative number for large u.
        # jax.scipy.special.hyp2f1 is numerically unstable in that regime.
        #
        # Use the exact hypergeometric transformation:
        #   2F1(a,b;c;z) = (1-z)^(-a) * 2F1(a, c-b; c; z/(z-1))
        # with a=1, b=1.5-beta, c=1.5, z=1-u^2.
        # Then (1-z)=u^2 and z/(z-1)=1-1/u^2 in (0,1) for u>1.
        if backend_key == "jax":
            resolved_n_kernel = _resolve_n_kernel(
                n_kernel, default=_default_constant_kernel_n_quad()
            )
            return _constant_kernel_jax_backend(
                jnp.asarray(u), beta_ani, n_kernel=resolved_n_kernel
            )

        u_arr = jnp.asarray(u)
        dtype = jnp.result_type(u_arr, beta_ani)
        one = jnp.asarray(1.0, dtype=dtype)
        eps = jnp.asarray(jnp.finfo(dtype).eps, dtype=dtype)
        u_safe = jnp.maximum(u_arr.astype(dtype), one + eps)
        u2 = u_safe**2

        hyp_main = jnp.asarray(
            _hyp2f1_1_b_3half_from_u_scipy(u_safe, beta_ani), dtype=dtype
        )
        hyp_asym = jnp.asarray(
            _hyp2f1_1_b_3half_asymptotic_from_u(u_safe, beta_ani), dtype=dtype
        )
        use_asym = (
            (u_safe > jnp.asarray(20.0, dtype=dtype))
            & (beta_ani > 0.0)
            & (beta_ani < 1.49)
        ) | (~jnp.isfinite(hyp_main))
        hyp_stable = jnp.asarray(jnp.where(use_asym, hyp_asym, hyp_main), dtype=dtype)

        pref = jnp.sqrt(1.0 - 1.0 / u2)
        kernel_val = pref * ((1.5 - beta_ani) * hyp_stable - 0.5)
        return jnp.where(u_arr <= 1.0, jnp.zeros_like(kernel_val), kernel_val)


class BaesAnisotropyModel(AnisotropyModel):
    r"""Baes & van Hese anisotropy model with numerical LOS kernel integration.

    Notes
    -----
    This follows the same kernel normalization used in `model.py`:

        sigma_los^2(R) = 2 * \int du [nu(uR)/Sigma(R)] * GM(uR) * K(u)/u

    so `K(u)` itself is computed without an extra prefactor 2 in the inner integral.

    **Inputs and units.** params follows the corresponding classical profile
    names: ``beta_ani``, or ``r_a``, or ``beta_0``/``beta_inf``/``r_a``/eta.
    Radii in pc and u=r/R dimensionless. kernel backend/order arguments are
    static numerical choices.

    **Returns and shape.** Dimensionless beta/kernel and integrating factor f,
    with broadcast shape.

    **Validity.** Require finite beta<1, positive transition radius/sharpness
    where applicable. Baes large eta needs numerical refinement; the default
    solver chooses Abel for general Baes.

    **Errors.** Invalid static backend/options raise; invalid physical proposals
    can produce NaN. Warnings flag known sharp-transition limitations.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Use the JAX kernel path. The explicit SciPy callback
    route is a reference, not a fully differentiated physical-parameter path.
    Verify gradients near branch and anisotropy limits.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    required_param_names = ("beta_0", "beta_inf", "r_a", "eta")

    def beta(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        r"""Baes & van Hese profile

        beta(r) = (beta_0 + beta_inf (r/r_a)^eta) / (1 + (r/r_a)^eta).
        """
        beta_0 = jnp.asarray(params["beta_0"])
        beta_inf = jnp.asarray(params["beta_inf"])
        r_a = jnp.asarray(params["r_a"])
        eta = jnp.asarray(params["eta"])

        r = jnp.asarray(r_pc)
        dtype = jnp.result_type(r, beta_0, beta_inf, r_a, eta)
        tiny = jnp.asarray(jnp.finfo(dtype).tiny, dtype=dtype)
        r_safe = jnp.maximum(r.astype(dtype), tiny)
        r_a_safe = jnp.maximum(r_a.astype(dtype), tiny)
        ell = eta.astype(dtype) * jnp.log(r_safe / r_a_safe)
        return beta_0 + (beta_inf - beta_0) * jax.nn.sigmoid(ell)

    def f(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        r"""Return

        f(r)=r^{2 beta_0} (1 + (r/r_a)^eta)^{2(beta_inf-beta_0)/eta}.
        """
        beta_0 = jnp.asarray(params["beta_0"])
        beta_inf = jnp.asarray(params["beta_inf"])
        r_a = jnp.asarray(params["r_a"])
        eta = jnp.asarray(params["eta"])

        r = jnp.asarray(r_pc)
        x = (r / r_a) ** eta
        return r ** (2.0 * beta_0) * (1.0 + x) ** (2.0 * (beta_inf - beta_0) / eta)

    def _log_f(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Logarithm of f(r) used for stable ratio evaluation f(s)/f(r)."""
        beta_0 = jnp.asarray(params["beta_0"])
        beta_inf = jnp.asarray(params["beta_inf"])
        r_a = jnp.asarray(params["r_a"])
        eta = jnp.asarray(params["eta"])

        r = jnp.asarray(r_pc)
        dtype = jnp.result_type(r, beta_0, beta_inf, r_a, eta)
        tiny = jnp.asarray(jnp.finfo(dtype).tiny, dtype=dtype)
        r_safe = jnp.maximum(r.astype(dtype), tiny)
        r_a_safe = jnp.maximum(r_a.astype(dtype), tiny)
        eta_safe = jnp.maximum(eta.astype(dtype), tiny)
        ell = eta_safe * jnp.log(r_safe / r_a_safe)
        return 2.0 * beta_0 * jnp.log(r_safe) + (
            2.0 * (beta_inf - beta_0) / eta_safe
        ) * jax.nn.softplus(ell)

    def kernel(
        self,
        u: jnp.ndarray,
        R_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        n_kernel: int = DEFAULT_BAES_KERNEL_N_QUAD,
    ) -> jnp.ndarray:
        r"""LOSVD kernel K(u) for general BAES anisotropy via numerical integration.

        Implements the note definition

            K(u_s) = f(Ru_s)/u_s * \int_1^{u_s} du
                     [u/sqrt(u^2-1)] * (1-beta(Ru)/u^2) / f(Ru).

        A fixed-grid JAX-friendly quadrature is used. The change of variables

            u=cosh(s),  s=arccosh(u)

        removes the endpoint singularity at u=1 and keeps the integration interval
        length O(log u), improving accuracy for very large u with fixed n_kernel.
        Internally, f-ratios are computed via log-differences for numerical
        stability in extreme beta regimes.

        Parameters
        ----------
        n_kernel:
            Number of Gauss-Legendre nodes for the inner quadrature.
        """
        _warn_if_baes_eta_large(params["eta"])
        return _baes_kernel_jax_backend(
            jnp.asarray(u),
            jnp.asarray(R_pc),
            jnp.asarray(params["beta_0"]),
            jnp.asarray(params["beta_inf"]),
            jnp.asarray(params["r_a"]),
            jnp.asarray(params["eta"]),
            n_kernel=int(n_kernel),
        )


class OsipkovMerrittModel(AnisotropyModel):
    r"""Osipkov-Merritt anisotropy model.

    This corresponds to the BAES special case (beta_0,beta_inf,eta)=(0,1,2):

        beta(r) = r^2 / (r^2 + r_a^2),
        f(r)    = 1 + r^2/r_a^2.

    Notes
    -----
    **Inputs and units.** params follows the corresponding classical profile
    names: ``beta_ani``, or ``r_a``, or ``beta_0``/``beta_inf``/``r_a``/eta.
    Radii in pc and u=r/R dimensionless. kernel backend/order arguments are
    static numerical choices.

    **Returns and shape.** Dimensionless beta/kernel and integrating factor f,
    with broadcast shape.

    **Validity.** Require finite beta<1, positive transition radius/sharpness
    where applicable. Baes large eta needs numerical refinement; the default
    solver chooses Abel for general Baes.

    **Errors.** Invalid static backend/options raise; invalid physical proposals
    can produce NaN. Warnings flag known sharp-transition limitations.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Use the JAX kernel path. The explicit SciPy callback
    route is a reference, not a fully differentiated physical-parameter path.
    Verify gradients near branch and anisotropy limits.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    required_param_names = ("r_a",)

    def beta(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Return beta(r)=r^2/(r^2+r_a^2)."""
        r_a = jnp.asarray(params["r_a"])
        r = jnp.asarray(r_pc)
        return r**2 / (r**2 + r_a**2)

    def f(self, r_pc: jnp.ndarray, *, params: Mapping[str, Any]) -> jnp.ndarray:
        """Return f(r)=1+r^2/r_a^2 from the note table."""
        r_a = jnp.asarray(params["r_a"])
        r = jnp.asarray(r_pc)
        return (r_a**2 + r**2) / r_a**2

    def kernel(
        self, u: jnp.ndarray, R_pc: jnp.ndarray, *, params: Mapping[str, Any]
    ) -> jnp.ndarray:
        r"""Closed-form K(u) for Osipkov-Merritt anisotropy.

        Uses the analytical expression equivalent to the note/CLUMPY formula,
        with u_a=r_a/R and u=r/R.
        """
        return _osipkov_kernel_jax_backend(
            jnp.asarray(u),
            jnp.asarray(R_pc),
            jnp.asarray(params["r_a"]),
        )


class DSphModel(Model):
    r"""Minimal Jeans model for sigma_los(R) using a fixed quadrature grid.

    This implementation is intentionally limited:
    - StellarModel: currently assumed to be PlummerModel-compatible interface
    - DMModel: any subclass implementing enclosed_mass(r_pc, params=...)
    - AnisotropyModel: any subclass implementing beta/f/kernel consistently

    It is sufficient for demonstrating MCMC with AIES/NUTS in tests.

    Notes
    -----
    **Inputs and units.** Compose StellarModel, DMModel and AnisotropyModel;
    params supplies all physical scalars. ``R_pc`` is scalar or nonempty 1-D pc.
    backend is auto/kernel/abel; jit controls cached compilation.
    ``n_u``/``n_kernel`` set outer/kernel rules; ``n_r`` sets Abel grid;
    ``u_max`` sets radial extent; ``dm_mass_n_steps`` sets mass integration
    independently.

    **Returns and shape.** Always a 1-D array of LOS variances in (km/s)^2,
    length one for scalar ``R_pc``.

    **Validity.** Finite R>0. Kernel auto selects constant/Osipkov-Merritt;
    general Baes uses Abel. The published preliminary accuracy envelope is not a
    universal error bound; refine each new domain.

    **Errors.** Invalid shape/backend/options raise ValueError; invalid dynamic
    radii or physical values yield NaN.

    **Backend.** JAX arrays on the configured CPU/GPU, with dtype set before
    import.

    **Differentiation.** Physical parameters on the supported JAX mass/kernel
    paths; static quadrature and backend choices are not differentiated.
    Abel-grid boundaries and finite integration extent affect accuracy.

    **Examples.** ``examples/docs_jax_spherical.py``
    """

    required_param_names = ("vmem_kms",)
    required_models = {
        "StellarModel": StellarModel,
        "DMModel": DMModel,
        "AnisotropyModel": AnisotropyModel,
    }

    def _resolve_dm_params_once(self, params: Mapping[str, Any]) -> Mapping[str, Any]:
        dm: DMModel = self.submodels["DMModel"]  # type: ignore[assignment]
        resolve_params = getattr(dm, "resolve_params", None)
        if not callable(resolve_params):
            return params
        resolved = dict(params)
        resolved.update(cast(Mapping[str, Any], resolve_params(params)))
        return resolved

    @staticmethod
    def _resolve_dm_mass_method(
        dm: DMModel, dm_mass_method: str
    ) -> str:
        method_key = str(dm_mass_method).strip().lower()
        if method_key not in {"auto", "analytic", "numeric"}:
            raise ValueError(
                "dm_mass_method must be 'auto', 'analytic', or 'numeric', "
                f"got {dm_mass_method!r}"
            )
        if method_key == "auto":
            return (
                "analytic"
                if (dm.analytic_enclosed_mass_autodiff_safe and dm.has_analytic_enclosed_mass)
                else "numeric"
            )
        return method_key

    def sigmalos2_kernel(
        self,
        R_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        n_u: Optional[int] = None,
        u_max: Optional[float] = None,
        n_kernel: Optional[int] = None,
        constant_kernel_backend: str = DEFAULT_CONSTANT_KERNEL_BACKEND,
        u_min_eps: float = 1e-6,
        kernel_outer_transform: str = DEFAULT_SIGMALOS2_KERNEL_OUTER_TRANSFORM,
        dm_mass_method: str = "auto",
        dm_mass_n_steps: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""Kernel-based sigma_los^2(R) implementation.

        With u=r/R, this computes

            sigma_los^2(R) = 2 * \int_1^\infty du
                [nu(uR)/Sigma(R)] [G M(uR)] K(u)/u.

        ``kernel_outer_transform='sqrtlog'`` uses ``log(u)=x^2``.  Since
        ``K(u) ~ sqrt(u-1)`` at the lower endpoint, the transformed integrand
        is smooth in ``x``.  ``'log'`` retains the legacy uniform-log(u) grid.

        The default ``sqrtlog`` grid is tuned to a maximum relative-error target
        of ``1e-3`` on the documented Plummer+NFW dSph stress benchmark.  For
        more extended or otherwise tail-sensitive models, increase ``u_max``
        before increasing ``n_u``; then double ``n_u`` to verify convergence.

        Notes
        -----
        **Inputs and units.** Positive ``R_pc`` in pc, scalar or nonempty 1-D array;
        params contains physical scalars. Use the signature's static
        numerical/backend options; ``n_u`` and ``n_kernel`` apply to the kernel
        route, ``n_r`` and ``u_max`` to the Abel grid, and ``dm_mass_n_steps`` to
        the mass integral.

        **Returns and shape.** Always a one-dimensional array of variances in
        (km/s)^2, length one for scalar input.
        """
        resolved_n_u = _default_sigmalos2_n_u() if n_u is None else int(n_u)
        resolved_u_max = _default_sigmalos2_u_max() if u_max is None else float(u_max)
        R, valid_R = _projected_radii(R_pc)
        dtype = R.dtype
        params = self._resolve_dm_params_once(params)
        transform_key = _normalize_kernel_outer_transform(kernel_outer_transform)

        u_max_arr = jnp.asarray(resolved_u_max, dtype=dtype)
        if transform_key == "sqrtlog":
            x = jnp.linspace(
                jnp.asarray(0.0, dtype=dtype),
                jnp.sqrt(jnp.log(u_max_arr)),
                resolved_n_u,
            )
            u = jnp.exp(x * x)
            dlogu_dx = 2.0 * x
        else:
            x = jnp.linspace(
                jnp.log1p(jnp.asarray(u_min_eps, dtype=dtype)),
                jnp.log(u_max_arr),
                resolved_n_u,
            )
            u = jnp.exp(x)
            dlogu_dx = jnp.ones_like(x)

        # Broadcast shapes: (n_R, n_u)
        R2d = R[:, None]
        u2d = u[None, :]
        r = R2d * u2d

        stellar: StellarModel = self.submodels["StellarModel"]  # type: ignore[assignment]
        dm: DMModel = self.submodels["DMModel"]  # type: ignore[assignment]
        ani: AnisotropyModel = self.submodels["AnisotropyModel"]  # type: ignore[assignment]
        dm_mass_method = self._resolve_dm_mass_method(dm, dm_mass_method)

        re_pc = params["re_pc"]
        nu3 = stellar.density_3d(r, re_pc=re_pc)
        sig2 = stellar.density_2d(R2d, re_pc=re_pc)
        mass_kwargs = {} if dm_mass_n_steps is None else {"n_steps": dm_mass_n_steps}
        M = dm.enclosed_mass(r, method=dm_mass_method, params=params, **mass_kwargs)

        kernel_kwargs: Dict[str, Any] = {}
        if isinstance(ani, ConstantAnisotropyModel):
            kernel_kwargs["backend"] = _normalize_constant_kernel_backend(
                constant_kernel_backend
            )
            if n_kernel is not None and kernel_kwargs["backend"] == "jax":
                kernel_kwargs["n_kernel"] = _resolve_n_kernel(
                    n_kernel, default=_default_constant_kernel_n_quad()
                )
        elif isinstance(ani, BaesAnisotropyModel) and n_kernel is not None:
            kernel_kwargs["n_kernel"] = _resolve_n_kernel(
                n_kernel, default=DEFAULT_BAES_KERNEL_N_QUAD
            )

        K = ani.kernel(u2d, R2d, params=params, **kernel_kwargs)
        grav = (GMsun_m3s2 * M / PARSEC_M) * 1e-6

        # du/u = dlog(u) = (dlog(u)/dx) dx.  For sqrtlog both K and
        # dlogu_dx vanish at x=0, regularizing the lower endpoint.
        integrand_x = 2.0 * K * (nu3 / sig2) * grav * dlogu_dx[None, :]
        if resolved_n_u > 1:
            h = x[1] - x[0]
            out = _simpson_uniform_last_axis(integrand_x, h)
        else:
            out = integrand_x[..., 0]
        return jnp.where(
            valid_R & jnp.isfinite(out) & (out >= 0)
            & jnp.all(jnp.isfinite(M) & (M >= 0), axis=-1),
            out,
            jnp.nan,
        )

    def sigmalos2_abel(
        self,
        R_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        n_r: Optional[int] = None,
        u_max: Optional[float] = None,
        r_min_factor: float = 0.5,
        dm_mass_method: str = "auto",
        dm_mass_n_steps: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""Compute sigma_los^2(R) via a 1D Jeans solve and two Abel transforms.

        Notes
        -----
        **Inputs and units.** Positive ``R_pc`` in pc, scalar or nonempty 1-D array;
        params contains physical scalars. Use the signature's static
        numerical/backend options; ``n_u`` and ``n_kernel`` apply to the kernel
        route, ``n_r`` and ``u_max`` to the Abel grid, and ``dm_mass_n_steps`` to
        the mass integral.

        **Returns and shape.** Always a one-dimensional array of variances in
        (km/s)^2, length one for scalar input.
        """
        R, valid_R = _projected_radii(R_pc)
        dtype = R.dtype
        resolved_n_r = _default_sigmalos2_n_r() if n_r is None else int(n_r)
        resolved_u_max = _default_sigmalos2_u_max() if u_max is None else float(u_max)
        params = self._resolve_dm_params_once(params)

        stellar: StellarModel = self.submodels["StellarModel"]  # type: ignore[assignment]
        dm: DMModel = self.submodels["DMModel"]  # type: ignore[assignment]
        ani: AnisotropyModel = self.submodels["AnisotropyModel"]  # type: ignore[assignment]
        dm_mass_method = self._resolve_dm_mass_method(dm, dm_mass_method)

        re_pc = jnp.asarray(params["re_pc"], dtype=dtype)
        r_min = jnp.maximum(
            jnp.min(R) * jnp.asarray(r_min_factor, dtype=dtype),
            jnp.asarray(1e-8, dtype=dtype),
        )
        r_max = jnp.max(R) * jnp.asarray(resolved_u_max, dtype=dtype)
        if "r_t_pc" in params:
            r_max = jnp.maximum(r_max, jnp.asarray(params["r_t_pc"], dtype=dtype))
        if "rs_pc" in params:
            r_max = jnp.maximum(
                r_max,
                jnp.asarray(20.0, dtype=dtype)
                * jnp.asarray(params["rs_pc"], dtype=dtype),
            )
        if "r_a" in params:
            r_max = jnp.maximum(
                r_max,
                jnp.asarray(20.0, dtype=dtype)
                * jnp.asarray(params["r_a"], dtype=dtype),
            )
        r_max = jnp.maximum(r_max, jnp.asarray(50.0, dtype=dtype) * re_pc)

        r, r_edges = _make_log_grid(r_min, r_max, resolved_n_r)
        log_r = jnp.log(r)

        nu3 = stellar.density_3d(r, re_pc=re_pc)
        beta = jnp.asarray(ani.beta(r, params=params), dtype=dtype)
        f_r = jnp.asarray(ani.f(r, params=params), dtype=dtype)
        mass_kwargs = {} if dm_mass_n_steps is None else {"n_steps": dm_mass_n_steps}
        mass = dm.enclosed_mass(r, method=dm_mass_method, params=params, **mass_kwargs)

        grav = (GMsun_m3s2 * mass / PARSEC_M) * 1e-6
        rhs_log_r = f_r * nu3 * grav / r
        jeans_integral = _reverse_cumtrapz_1d(rhs_log_r, log_r)
        radial_moment = jeans_integral / f_r

        abel_rj = _abel_transform_piecewise_constant(r * radial_moment, R, r_edges)
        abel_beta_j_over_r = _abel_transform_piecewise_constant(
            beta * radial_moment / r, R, r_edges
        )

        sigma = stellar.density_2d(R, re_pc=re_pc)
        numer = 2.0 * (abel_rj - (R**2) * abel_beta_j_over_r)
        out = numer / sigma
        return jnp.where(
            valid_R & jnp.isfinite(out) & (out >= 0)
            & jnp.all(jnp.isfinite(mass) & (mass >= 0)),
            out,
            jnp.nan,
        )

    def sigmalos2(
        self,
        R_pc: jnp.ndarray,
        *,
        params: Mapping[str, Any],
        backend: str = "auto",
        jit: Optional[bool] = None,
        n_u: Optional[int] = None,
        n_r: Optional[int] = None,
        n_kernel: Optional[int] = None,
        u_max: Optional[float] = None,
        constant_kernel_backend: str = DEFAULT_CONSTANT_KERNEL_BACKEND,
        u_min_eps: float = 1e-6,
        kernel_outer_transform: str = DEFAULT_SIGMALOS2_KERNEL_OUTER_TRANSFORM,
        r_min_factor: float = 0.5,
        dm_mass_method: str = "auto",
        dm_mass_n_steps: Optional[int] = None,
    ) -> jnp.ndarray:
        r"""Compute sigma_los^2(R) via the requested backend.

        ``backend`` may be ``'abel'``, ``'kernel'``, or ``'auto'``.  When set to
        ``'auto'`` the choice is made based on the anisotropy model:
        Baes --> Abel, constant/Osipkov-Merritt --> kernel (see benchmarks).

        ``jit`` controls whether a cached ``jax.jit`` wrapper is used around the
        selected solver. ``None`` defaults to the cached JIT path.

        R_pc must be a scalar or a nonempty 1-D array. Results are always 1-D
        (length one for a scalar). Only finite R_pc > 0 are supported; invalid
        elements return NaN in eager and JIT execution without contaminating
        other elements. R=0 needs a model-dependent central-limit solver.

        ``dm_mass_method`` controls the dark-matter enclosed-mass backend and
        must be one of ``"auto"``, ``"analytic"``, or ``"numeric"``. The
        default ``"auto"`` follows the DM model's autodiff-safe choice:
        analytic for NFW and numeric for Zhao.
        ``dm_mass_n_steps`` sets the numerical mass resolution independently
        of the outer Jeans grid. Analytic mass methods ignore this resolution.

        For the kernel backend, the documented ``1e-3`` accuracy target applies
        to the sampled Plummer+NFW stress envelope described in the README.
        Outside that envelope, test convergence by increasing ``u_max`` first
        and then doubling ``n_u``.  The Abel backend has a separate radial-grid
        convergence control, ``n_r``.

        Notes
        -----
        **Inputs and units.** Positive ``R_pc`` in pc, scalar or nonempty 1-D array;
        params contains physical scalars. Use the signature's static
        numerical/backend options; ``n_u`` and ``n_kernel`` apply to the kernel
        route, ``n_r`` and ``u_max`` to the Abel grid, and ``dm_mass_n_steps`` to
        the mass integral.

        **Returns and shape.** Always a one-dimensional array of variances in
        (km/s)^2, length one for scalar input.
        """
        backend_key = str(backend).strip().lower()
        ani = self.submodels["AnisotropyModel"]  # type: ignore[index]
        if backend_key in ("auto", ""):
            if isinstance(ani, BaesAnisotropyModel):
                backend_key = "abel"
            elif isinstance(ani, (ConstantAnisotropyModel, OsipkovMerrittModel)):
                backend_key = "kernel"
            else:
                backend_key = "abel"

        if backend_key not in {"abel", "kernel"}:
            raise ValueError(
                f"backend must be 'abel','kernel' or 'auto', got {backend!r}"
            )

        use_jit = DEFAULT_SIGMALOS2_JIT if jit is None else bool(jit)
        if (isinstance(ani, BaesAnisotropyModel) and "eta" in ani.required_param_names
                and (use_jit or backend_key == "abel")):
            _warn_if_baes_eta_large(params["eta"])
        dm: DMModel = self.submodels["DMModel"]  # type: ignore[assignment]
        dm_mass_method = self._resolve_dm_mass_method(dm, dm_mass_method)

        resolved_n_u = _default_sigmalos2_n_u() if n_u is None else int(n_u)
        resolved_n_r = _default_sigmalos2_n_r() if n_r is None else int(n_r)
        resolved_u_max = _default_sigmalos2_u_max() if u_max is None else float(u_max)
        resolved_n_kernel = (
            None
            if n_kernel is None
            else _resolve_n_kernel(n_kernel, default=DEFAULT_BAES_KERNEL_N_QUAD)
        )
        constant_kernel_backend_key = _normalize_constant_kernel_backend(
            constant_kernel_backend
        )
        kernel_outer_transform_key = (
            _normalize_kernel_outer_transform(kernel_outer_transform)
            if backend_key == "kernel"
            else DEFAULT_SIGMALOS2_KERNEL_OUTER_TRANSFORM
        )

        def _eval(R_value: jnp.ndarray, params_value: Mapping[str, Any]) -> jnp.ndarray:
            if backend_key == "abel":
                return self.sigmalos2_abel(
                    R_value,
                    params=params_value,
                    n_r=resolved_n_r,
                    u_max=resolved_u_max,
                    r_min_factor=r_min_factor,
                    dm_mass_method=dm_mass_method,
                    dm_mass_n_steps=dm_mass_n_steps,
                )
            return self.sigmalos2_kernel(
                R_value,
                params=params_value,
                n_u=resolved_n_u,
                n_kernel=resolved_n_kernel,
                u_max=resolved_u_max,
                constant_kernel_backend=constant_kernel_backend_key,
                u_min_eps=u_min_eps,
                kernel_outer_transform=kernel_outer_transform_key,
                dm_mass_method=dm_mass_method,
                dm_mass_n_steps=dm_mass_n_steps,
            )

        if not use_jit:
            return _eval(R_pc, params)

        cache_key = (
            backend_key,
            resolved_n_u,
            resolved_n_r,
            resolved_n_kernel,
            resolved_u_max,
            constant_kernel_backend_key,
            kernel_outer_transform_key,
            float(u_min_eps),
            float(r_min_factor),
            dm_mass_method,
            dm_mass_n_steps,
            bool(jax.config.read("jax_enable_x64")),
            jax.default_backend(),
        )
        compiled = self._jit_cache.get(cache_key)
        if compiled is None:
            compiled = jax.jit(_eval)
            self._jit_cache[cache_key] = compiled

        return compiled(R_pc, params)


from .axisymmetric_numpyro import AxisymmetricDSphModel


__all__ = [
    "AxisymmetricDSphModel",
    "Model",
    "PlummerModel",
    "ZhaoModel",
    "NFWModel",
    "ConstantAnisotropyModel",
    "BaesAnisotropyModel",
    "OsipkovMerrittModel",
    "DSphModel",
    "configure_runtime",
    "get_runtime_config",
]
