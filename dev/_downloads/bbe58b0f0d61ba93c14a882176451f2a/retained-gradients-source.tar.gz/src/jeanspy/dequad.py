from numpy import sinh,cosh,exp,log,pi,arange,isnan,isinf,float64
from functools import lru_cache, wraps
import numpy as np
import warnings

DEBUG = False
BUF_DEBUG = None

def hashable(x):
    r"""Test whether Python can hash an object.

    Notes
    -----
    **Inputs and units.** x is any Python object.

    **Returns and shape.** bool; catches TypeError from hash(x).

    **Validity.** Hashability is not a check of array content identity.

    **Errors.** Exceptions other than TypeError propagate.

    **Backend.** Python host.

    **Differentiation.** No physical-parameter automatic differentiation on this
    API.

    **Examples.** hashable((1,2)) is True; hashable(np.array([1])) is False.
    """
    try:
        hash(x)
        return True
    except TypeError:
        return False

# 関数を Memoize するデコレータ.
def memorize(callable):
    r"""Cache a callable for hashable argument tuples.

    Notes
    -----
    **Inputs and units.** callable is a Python function; the wrapper accepts its
    positional/keyword arguments.

    **Returns and shape.** Wrapped callable with an in-memory cache; unhashable
    arguments bypass caching.

    **Validity.** Pure functions only; key order follows supplied kwargs.
    Mutable returned values are shared cached objects.

    **Errors.** Original callable exceptions propagate.

    **Backend.** Python host.

    **Differentiation.** No physical-parameter automatic differentiation on this
    API.

    **Examples.** Used internally for quadrature nodes; use dequad for numerical
    integration.
    """
    cache = {}
    @wraps(callable)
    def wrapper(*args, **kwargs):
        key = args + tuple(kwargs.items())
        if not hashable(key):
            return callable(*args, **kwargs)
        if key not in cache:
            cache[key] = callable(*args, **kwargs)
        return cache[key]
    return wrapper

#@lru_cache(maxsize = 1)
@memorize
def generate_x_w(a,b,n,xp=np):
    r"""Construct nodes and weights for fixed double-exponential quadrature.

    Parameters
    ----------
    a, b : float
        Scalar interval endpoints in the integration coordinate's units.
        Supported intervals are finite ``(a, b)``, ``(a, +inf)`` and
        ``(-inf, +inf)``. Vector-valued endpoints are not a supported contract.
    n : int
        Number of nodes, at least two. Refine this count to check convergence.
    xp : module, optional
        Array namespace for the coordinate transform; NumPy by default.
        Node selection and interval checks still use NumPy.

    Returns
    -------
    x, w : ndarray
        Nodes and weights, each shape ``(n,)`` for scalar endpoints. Weights
        include the coordinate transformation and integration step. Both
        arrays have the integration coordinate's units.

    Notes
    -----
    Invalid interval combinations or orders are not uniformly validated.
    This host-side node generator is not an end-to-end JAX tracing contract.
    Hashable arguments reuse cached arrays; returned arrays must not be
    mutated if that cache is to remain valid. See ``examples/docs_numerics.py``.
    """
    #print("generate_x_w in",a,b,width,mN,pN)
    pi2 = xp.pi/2
    
    if np.all(np.isfinite(a)) and np.all(np.isinf(b)):  # a < x < inf
        ts = np.linspace(-6.85,6.79,n)  # finite x, finite w, w!=0
        width = ts[1] - ts[0]
        ps = pi2*xp.sinh(ts)
        xs = xp.exp(ps) + a
        ws = width *pi2 *xp.cosh(ts)*xp.exp(ps)    
        
    elif np.all(np.isinf(a)) and np.all(np.isinf(b)):  # -inf < x < inf
        ts = np.linspace(-6.79,6.79,n)  # finite x, finite w, w!=0
        width = ts[1] - ts[0]
        ps = pi2*xp.sinh(ts)
        xs = xp.sinh(ps)
        ws = width *pi2 *xp.cosh(ts)*xp.cosh(ps)  
        
    elif np.all(np.isfinite(a)) and np.all(np.isfinite(b)):  # a < x < b
        ts = np.linspace(-6.10,6.10,n)  # finite x, finite w, w!=0
        width = ts[1] - ts[0]
        ps = pi2*xp.sinh(ts)
        xs = (b-a)/2*xp.tanh(ps) + (a+b)/2
        ws = width * (b-a)/2 *pi2 *xp.cosh(ts)/xp.cosh(ps)/xp.cosh(ps)
        
    return xs,ws


def dequad(func,a,b,n,
           axis=-1,xp=np,
           replace_inf_to_zero=False,
           replace_nan_to_zero=False,
           reshape_ws = None,
           verbose=False):
    r"""Integrate a vectorized function with fixed double-exponential nodes.

    Parameters
    ----------
    func : callable
        Receives nodes of shape ``(n,)`` and returns values whose integration
        axis has length ``n``. For output ``(m, n)``, the default axis works.
    a, b : float
        Integration limits in the input coordinate's units. Supported domains
        are finite intervals, ``(a, +inf)`` and the two-sided infinite line.
    n : int
        Number of nodes; use at least two and check refinement explicitly.
    axis : int, optional
        Axis summed in the function output, default ``-1``.
    xp : module, optional
        Array namespace for node construction; NumPy by default. Validation
        and replacement logic use NumPy, so this is not a traced JAX API.
    replace_inf_to_zero, replace_nan_to_zero : bool, optional
        Replace the corresponding weighted values with zero. Both default
        to false; enabling either can discard real numerical failures.
    reshape_ws : tuple or None, optional
        Optional shape for broadcasting weights against function output.
    verbose : bool, optional
        Print the weighted integrand if true.

    Returns
    -------
    scalar or ndarray
        Weighted sum with the integration axis removed, in function-output
        units times integration-coordinate units. No error estimate is returned.

    Warns
    -----
    UserWarning
        Nonfinite weighted values are present and their replacement is disabled.

    Notes
    -----
    **Validity.** Refine n to verify convergence; nonfinite replacement can
    discard failures.

    **Errors.** Nonfinite weighted values issue warnings unless the explicit
    replacement option is enabled.

    **Backend.** NumPy CPU; xp is not an end-to-end JAX contract.

    **Differentiation.** No physical-parameter automatic differentiation on this
    API.

    **Examples.** ``examples/docs_numerics.py``

    Examples
    --------
    >>> from jeanspy.dequad import dequad
    >>> bool(np.isclose(dequad(lambda x: x**2, 0., 1., 256), 1. / 3.))
    True
    """
    xs,ws = generate_x_w(a,b,n,xp)
    fs = func(xs)
    ws = ws if reshape_ws is None else ws.reshape(reshape_ws)
    wsfs = ws * fs

     
    if replace_inf_to_zero:
        wsfs[np.isinf(wsfs)] = 0
    elif np.any(np.isinf(wsfs)):
        warnings.warn("inf is detected in dequad calculation. Use \"replace_inf_to_zero\" to ignore such elements")
        
    if replace_nan_to_zero:
        wsfs[np.isnan(wsfs)] = 0
    elif np.any(np.isnan(wsfs)):
        warnings.warn("nan is detected in dequad calculation. Use \"replace_nan_to_zero\" to ignore such elements")
        
    if verbose:    
        print(wsfs)
        
    return (wsfs).sum(axis=axis)
    

if __name__ == "__main__":
    #### demonstration and illustration ####
    
    import matplotlib.pyplot as plt
    import numpy as np
    
    def debug(func,a,b):
        ns = range(1,20)
        errs = [np.abs(1-dequad(func,a,b,n=2**i)) for i in ns]
        print(errs)
        plt.plot(list(ns),errs)
        plt.yscale("log")
        
    debug(lambda x: 1/np.sqrt(2*np.pi)*np.exp(-x**2/2),np.inf,np.inf)
    debug(lambda x: 1/x**2,1,np.inf)
    debug(lambda x: 2*np.exp(-x)*np.sin(x),0,np.inf)
    debug(lambda x: 2*x,0,1)
    
    plt.show()  # The plotted figure shows that n = 2**6~2**10 (64~1024) is good for the normal use
