#!/usr/bin/env python3
"""Run the frozen selected-point physical-parameter Jacobian validation.

This is a bounded numerical study. It does not perform posterior inference.
The parent process should enforce the protocol's wall-clock/resource limits.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
import resource
import subprocess
import sys
import time
import traceback
import warnings

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np
from jeanspy._jax_env import configure_jax_environment
configure_jax_environment()
import jax
import jax.numpy as jnp


def clean(value):
    if isinstance(value, dict):
        return {str(k): clean(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [clean(v) for v in value]
    if isinstance(value, np.ndarray):
        return clean(value.tolist())
    if isinstance(value, np.generic):
        return clean(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return str(value)
    return value


def save(path, report):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(clean(report), indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def finite(array):
    return bool(np.isfinite(np.asarray(array)).all())


def relative(actual, expected):
    actual, expected = np.asarray(actual), np.asarray(expected)
    if not finite(actual) or not finite(expected):
        return None
    return float(np.max(np.abs(actual - expected) / np.maximum(np.abs(expected), 1e-12)))


def normalized(actual, expected, prediction, scales):
    if not finite(actual) or not finite(expected):
        return None
    return float(np.max(np.abs(np.asarray(actual)-np.asarray(expected)) * scales[None, :]
                        / np.maximum(np.abs(prediction), 1e-12)[:, None]))


def derivative_relative(actual, expected):
    if not finite(actual) or not finite(expected):
        return None
    denominator = np.maximum(np.maximum(np.abs(actual), np.abs(expected)), 1e-12)
    return float(np.max(np.abs(actual-expected)/denominator))


def timed(function, argument):
    started = time.perf_counter()
    result = jax.block_until_ready(function(argument))
    return time.perf_counter()-started, np.asarray(result)


def spherical_model(case, module):
    anisotropy_class = {"constant": "ConstantAnisotropyModel", "om": "OsipkovMerrittModel",
                        "baes": "BaesAnisotropyModel"}[case["anisotropy"]]
    return module.DSphModel(submodels={"StellarModel": module.PlummerModel(),
        "DMModel": module.NFWModel() if case["halo"] == "nfw" else module.ZhaoModel(),
        "AnisotropyModel": getattr(module, anisotropy_class)()})


def forward_function(kind, case, order, protocol, names):
    coordinates = protocol["coordinates"]
    if kind == "spherical":
        from jeanspy import model_numpyro as module
        model = spherical_model(case, module)
        settings = protocol[kind]
        radii = jnp.asarray(coordinates["R_pc"], dtype=float)
        def forward(theta):
            return model.sigmalos2(radii, params=dict(zip(names, theta)), backend="kernel",
                n_u=order, n_kernel=order, u_max=settings["u_max"],
                kernel_outer_transform=settings["kernel_outer_transform"],
                constant_kernel_backend=settings["constant_kernel_backend"],
                dm_mass_method="numeric" if case["halo"] == "zhao" else "analytic",
                dm_mass_n_steps=settings["dm_mass_n_steps"])
    else:
        from jeanspy.axisymmetric_numpyro import AxisymmetricDSphModel
        model = AxisymmetricDSphModel(order, order, order)
        x = jnp.asarray(coordinates["x_pc"], dtype=float)
        y = jnp.asarray(coordinates["y_pc"], dtype=float)
        def forward(theta):
            return model.sigmalos2(x, y, params=dict(zip(names, theta)))
    return jax.jit(forward)


def classical_reference(kind, case, protocol):
    coordinates = protocol["coordinates"]
    values = []
    if kind == "spherical":
        from jeanspy import model as module
        model = spherical_model(case, module)
        model.update(**case["params"])
        for order in protocol[kind]["classical_de_orders"]:
            prediction = model.sigmalos2(np.array(coordinates["R_pc"]), n=order,
                n_kernel=protocol[kind]["classical_n_kernel"], ignore_RuntimeWarning=False)
            values.append(dict(order=order, prediction=np.asarray(prediction)))
    else:
        from jeanspy.axisymmetric import AxisymmetricDSphModel
        for order in protocol[kind]["numpy_reference_orders"]:
            model = AxisymmetricDSphModel(order, order, order)
            prediction = model.sigmalos2(coordinates["x_pc"], coordinates["y_pc"], params=case["params"])
            values.append(dict(order=order, prediction=np.asarray(prediction)))
    return values


def evaluate(kind, case, protocol, result, persist):
    names = list(case["params"])
    theta_host = np.array([case["params"][name] for name in names])
    scales = np.maximum(np.abs(theta_host), .1)
    theta = jnp.asarray(theta_host, dtype=float)
    result.update(parameter_names=names, params=case["params"], parameter_scales=scales,
                  configurations=[], status="running")
    persist()
    started = time.perf_counter()
    result["numpy_reference"] = classical_reference(kind, case, protocol)
    result["numpy_reference_seconds"] = time.perf_counter()-started
    result["numpy_reference_refinement_relative"] = relative(
        result["numpy_reference"][-2]["prediction"], result["numpy_reference"][-1]["prediction"])
    persist()
    for order in protocol[kind]["orders"]:
        configuration = dict(order=order, status="running")
        result["configurations"].append(configuration)
        persist()
        function = forward_function(kind, case, order, protocol, names)
        first_seconds, prediction = timed(function, theta)
        warm_seconds, repeated = timed(function, theta)
        derivative = jax.jit(jax.jacrev(function))
        derivative_first, jacobian = timed(derivative, theta)
        derivative_warm, _ = timed(derivative, theta)
        differences = []
        for fraction in protocol["finite_difference"]["relative_steps"]:
            columns = []
            for index in range(len(names)):
                step = fraction*scales[index]
                unit = np.zeros(len(names)); unit[index] = step
                samples = [np.asarray(jax.block_until_ready(function(
                    jnp.asarray(theta_host + multiplier*unit, dtype=float)))) for multiplier in [-2, -1, 1, 2]]
                columns.append((samples[0] - 8*samples[1] + 8*samples[2] - samples[3])/(12*step))
            fd = np.stack(columns, axis=1)
            differences.append(dict(relative_step=fraction, jacobian=fd,
                normalized_ad_fd_error=normalized(jacobian, fd, prediction, scales),
                derivative_relative_error=derivative_relative(jacobian, fd)))
        agreement = normalized(differences[0]["jacobian"], differences[1]["jacobian"], prediction, scales)
        dtype = "float64" if jax.config.jax_enable_x64 else "float32"
        gates = protocol["gates"]
        checks = dict(all_finite=finite(prediction) and finite(jacobian) and
                      all(finite(row["jacobian"]) for row in differences),
                      ad_fd=all(row["normalized_ad_fd_error"] is not None and
                                row["normalized_ad_fd_error"] <= gates["max_normalized_ad_fd_error_"+dtype]
                                for row in differences),
                      fd_steps=agreement is not None and agreement <=
                               gates["max_normalized_fd_step_disagreement_"+dtype])
        configuration.update(status="completed", prediction=prediction, jacobian=jacobian,
            finite_differences=differences, fd_step_disagreement_normalized=agreement, gates=checks,
            timings_seconds=dict(first_forward=first_seconds, warm_forward=warm_seconds,
                                  first_jacobian=derivative_first, warm_jacobian=derivative_warm),
            repeat_relative_difference=relative(repeated, prediction))
        persist()
    last, previous = result["configurations"][-1], result["configurations"][-2]
    value_refinement = relative(previous["prediction"], last["prediction"])
    gradient_refinement = normalized(previous["jacobian"], last["jacobian"], last["prediction"], scales)
    reference_error = relative(last["prediction"], result["numpy_reference"][-1]["prediction"])
    result.update(status="completed", finest_reference_relative=reference_error,
        intermediate_finest_value_relative=value_refinement,
        intermediate_finest_gradient_normalized=gradient_refinement,
        refinement_gates=dict(
            value_reference=reference_error is not None and reference_error <= protocol["gates"]["max_finest_value_reference_relative"],
            values=value_refinement is not None and value_refinement <= protocol["gates"]["max_intermediate_finest_value_relative"],
            gradients=gradient_refinement is not None and gradient_refinement <= protocol["gates"]["max_intermediate_finest_gradient_normalized"]))
    persist()
    jax.clear_caches()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, default=ROOT/"validation/release/gradient_protocol.json")
    args = parser.parse_args()
    if args.output.exists():
        parser.error("output already exists; preserve previous results")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    protocol = json.loads(args.protocol.read_text())
    condition = jax.default_backend()+("-float64" if jax.config.jax_enable_x64 else "-float32")
    if condition not in protocol["conditions"]:
        parser.error("actual device/precision is not a declared condition")
    report = dict(protocol=protocol, protocol_sha256=hashlib.sha256(args.protocol.read_bytes()).hexdigest(),
        started_utc=datetime.now(timezone.utc).isoformat(), condition=condition, status="running",
        argv=sys.argv, platform=platform.platform(), devices=[str(d) for d in jax.devices()],
        cpu_affinity=sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        versions={name:version(name) for name in ["numpy", "scipy", "jax", "jaxlib"]},
        git_commit=subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        runtime_sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in (ROOT/"src/jeanspy").rglob("*.py")},
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), cases=[])
    started = time.perf_counter()
    def persist():
        report["elapsed_seconds"] = time.perf_counter()-started
        report["peak_rss_kib"] = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
        try:
            report["gpu_allocator_statistics"] = jax.devices()[0].memory_stats()
        except (AttributeError, RuntimeError):
            report["gpu_allocator_statistics"] = None
        save(args.output, report)
    persist()
    for kind in ["spherical", "axisymmetric"]:
        for case in protocol[kind]["cases"]:
            row = dict(id=case["id"], geometry=kind)
            report["cases"].append(row)
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                try:
                    evaluate(kind, case, protocol, row, persist)
                except Exception as error:
                    row.update(status="failed", error=repr(error), traceback=traceback.format_exc())
                row["warnings"] = [dict(category=w.category.__name__, message=str(w.message)) for w in caught]
                persist()
            print(json.dumps(dict(condition=condition, case=case["id"], status=row["status"],
                                  reference_error=row.get("finest_reference_relative"))), flush=True)
    report["all_gates_passed"] = all(
        row["status"] == "completed" and all(row["refinement_gates"].values()) and
        all(all(config["gates"].values()) for config in row["configurations"])
        for row in report["cases"])
    if any(row["status"] == "failed" for row in report["cases"]):
        report["status"] = "completed_with_execution_failures"
    elif not report["all_gates_passed"]:
        report["status"] = "completed_with_failed_gates"
    else:
        report["status"] = "completed_all_gates_passed"
    report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    persist()


if __name__ == "__main__":
    main()
