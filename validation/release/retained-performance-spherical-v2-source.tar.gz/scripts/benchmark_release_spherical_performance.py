#!/usr/bin/env python3
"""Repaired spherical timings with an explicit fixed untruncated NFW halo.

Retains the v1 failed attempts; see spherical_performance_repair_protocol.json.
"""
from __future__ import annotations
import argparse
from datetime import datetime,timezone
import hashlib,json,os,resource,sys,time,traceback,warnings
from importlib.metadata import version
from pathlib import Path
from validate_physical_gradients import ROOT,spherical_model
from generate_release_mocks import save
import numpy as np
import jax,jax.numpy as jnp
from jeanspy import model as classical
from jeanspy import model_numpyro as spherical_jax
from jeanspy.axisymmetric import AxisymmetricDSphModel as AxisNumpy
from jeanspy.axisymmetric_numpyro import AxisymmetricDSphModel as AxisJax


def elapsed(fn):
    start=time.perf_counter();value=jax.block_until_ready(fn());return time.perf_counter()-start,value

def repeats(fn,count):
    values=[elapsed(fn)[0] for _ in range(count)]
    return dict(seconds=values,median_seconds=float(np.median(values)),p10_seconds=float(np.quantile(values,.1)),p90_seconds=float(np.quantile(values,.9)))

def relative(a,b):return float(np.max(np.abs(np.asarray(a)-b)/np.maximum(np.abs(b),1e-12)))


def evaluate(kind,count,protocol,row,persist):
    jax.clear_caches();case=protocol[kind];params=case['params'];names=list(params)
    prep=time.perf_counter()
    radius=np.geomspace(10.,1500.,count);phi=2*np.pi*((np.arange(count)*.6180339887498949)%1)
    host=(radius,radius*np.cos(phi),.8*radius*np.sin(phi),4*np.sin(np.arange(count)*.71),np.full(count,2.))
    row.update(host_preparation_seconds=time.perf_counter()-prep,parameter_names=names,params=params)
    numpy_start=time.perf_counter()
    if kind=='spherical':
        numpy_model=spherical_model(case,classical);numpy_model.update(**params,r_t_pc=np.inf)
        numpy_fn=lambda:numpy_model.sigmalos2(host[0],n=case['classical_de_orders'][0],n_kernel=case['classical_n_kernel'],ignore_RuntimeWarning=False)
    else:
        numpy_model=AxisNumpy(*([case['order']]*3))
        numpy_fn=lambda:numpy_model.sigmalos2(host[1],host[2],params=params)
    row['numpy_model_construction_seconds']=time.perf_counter()-numpy_start
    first,np_value=elapsed(numpy_fn);row['numpy_first_prediction_seconds']=first
    row['numpy_warm_prediction']=repeats(numpy_fn,protocol['timing']['numpy_prediction_repeats']);persist()
    prep=time.perf_counter()
    jax_model=spherical_model(case,spherical_jax) if kind=='spherical' else AxisJax(*([case['order']]*3))
    row['jax_model_construction_seconds']=time.perf_counter()-prep
    transfer,data=elapsed(lambda:tuple(jax.device_put(np.asarray(v,dtype=np.float64 if jax.config.jax_enable_x64 else np.float32)) for v in host))
    row['input_host_to_device_seconds']=transfer
    theta=jnp.array(list(params.values()),dtype=float)
    def forward(theta):
        p={'r_t_pc':jnp.inf,**dict(zip(names,theta))}
        if kind=='spherical':
            return jax_model.sigmalos2(data[0],params=p,backend='kernel',n_u=case['order'],n_kernel=case['order'],u_max=case['u_max'],
                kernel_outer_transform=case['kernel_outer_transform'],constant_kernel_backend=case['constant_kernel_backend'],dm_mass_method='analytic')
        return jax_model.sigmalos2(data[1],data[2],params=p)
    function=jax.jit(forward)
    cold,prediction=elapsed(lambda:function(theta));row['jax_first_prediction_seconds']=cold
    row['jax_warm_prediction']=repeats(lambda:function(theta),protocol['timing']['warm_prediction_repeats'])
    transfer,host_prediction=elapsed(lambda:np.asarray(prediction));row['prediction_device_to_host_seconds']=transfer
    row['predictions']=dict(numpy=np.asarray(np_value),jax=host_prediction)
    error=relative(host_prediction,np_value);row['numpy_jax_max_relative_difference']=error
    row['gates']=dict(finite=bool(np.all(np.isfinite(host_prediction)) and np.all(host_prediction>0)),numpy_jax=error<=protocol['accuracy']['max_numpy_jax_prediction_relative_difference'])
    if kind=='axisymmetric':
        ids=np.linspace(0,count-1,min(count,protocol['accuracy']['refinement_position_count']),dtype=int)
        fine=AxisNumpy(*([protocol['accuracy']['axisymmetric_refinement_order']]*3)).sigmalos2(host[1][ids],host[2][ids],params=params)
        error=relative(np.asarray(np_value)[ids],fine);row['numpy_refinement_max_relative_difference']=error
        row['gates']['refinement']=error<=protocol['accuracy']['max_axisymmetric_refinement_relative_difference']
    row['gradient_workloads']=[];persist()
    for active in case['active_parameter_counts']:
        fixed=theta
        def likelihood(variable):
            p=fixed.at[:active].set(variable);variance=forward(p)+data[4]**2
            return -.5*jnp.sum(jnp.log(2*jnp.pi*variance)+data[3]**2/variance)
        derivative=jax.jit(jax.value_and_grad(likelihood));variables=theta[:active]
        cold,value=elapsed(lambda:derivative(variables));warm=repeats(lambda:derivative(variables),protocol['timing']['warm_gradient_repeats'])
        transfer,host_value=elapsed(lambda:tuple(np.asarray(v) for v in value))
        row['gradient_workloads'].append(dict(active_parameters=names[:active],count=active,first_value_and_gradient_seconds=cold,warm_value_and_gradient=warm,
             result_device_to_host_seconds=transfer,log_likelihood=float(host_value[0]),gradient=host_value[1],finite=bool(np.all(np.isfinite(host_value[1])))))
        persist()
    row['gates']['gradients_finite']=all(r['finite'] for r in row['gradient_workloads'])
    row['status']='completed_all_accuracy_gates_passed' if all(row['gates'].values()) else 'completed_with_failed_accuracy_gates'


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--output',required=True,type=Path)
    p.add_argument('--protocol',type=Path,default=ROOT/'validation/release/spherical_performance_repair_protocol.json');args=p.parse_args()
    if args.output.exists():p.error('output exists; retain earlier attempts')
    protocol=json.loads(args.protocol.read_text());dtype='float64' if jax.config.jax_enable_x64 else 'float32';condition=jax.default_backend()+'-'+dtype
    if condition not in protocol['conditions']:p.error('undeclared condition')
    report=dict(status='running',protocol=protocol,protocol_sha256=hashlib.sha256(args.protocol.read_bytes()).hexdigest(),condition=condition,
         devices=[str(d) for d in jax.devices()],cpu_affinity=sorted(os.sched_getaffinity(0)),versions={k:version(k) for k in ['numpy','scipy','jax','jaxlib']},
         script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runtime_sources={str(f.relative_to(ROOT)):hashlib.sha256(f.read_bytes()).hexdigest() for f in (ROOT/'src/jeanspy').rglob('*.py')},
         started_utc=datetime.now(timezone.utc).isoformat(),cases=[])
    start=time.perf_counter()
    def persist():report['elapsed_seconds']=time.perf_counter()-start;report['peak_host_rss_bytes']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*1024;save(args.output,report)
    persist()
    for kind in ['spherical']:
      for count in protocol['data_counts']:
        row=dict(kind=kind,n_data=count,status='running');report['cases'].append(row);persist();local=time.perf_counter()
        with warnings.catch_warnings(record=True) as caught:
          warnings.simplefilter('always')
          try:evaluate(kind,count,protocol,row,persist)
          except Exception:row.update(status='execution_failed',exception=traceback.format_exc());print(row['exception'],flush=True)
          finally:row.update(elapsed_seconds=time.perf_counter()-local,warnings=[dict(category=w.category.__name__,message=str(w.message)) for w in caught]);persist()
        print(json.dumps(dict(kind=kind,n=count,status=row['status'],elapsed=row['elapsed_seconds'])),flush=True)
    report['status']='completed_with_execution_failures' if any(r['status']=='execution_failed' for r in report['cases']) else ('completed_all_accuracy_gates_passed' if all(all(r['gates'].values()) for r in report['cases']) else 'completed_with_failed_accuracy_gates')
    report['finished_utc']=datetime.now(timezone.utc).isoformat();persist()
    return int(report['status']=='completed_with_execution_failures')

if __name__=='__main__':sys.exit(main())
