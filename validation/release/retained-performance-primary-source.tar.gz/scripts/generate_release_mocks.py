#!/usr/bin/env python3
"""Generate the frozen Gaussian controls and independently constructed AGAMA mocks.

Use run_budgeted_experiment.py to enforce the declared cumulative/resource limits.
Each run writes immutable data arrays and a progressively saved provenance report.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback
import warnings

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
import numpy as np
from jeanspy.axisymmetric import G, AxisymmetricDSphModel


def serial(value):
    if isinstance(value, dict):
        return {str(k): serial(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [serial(v) for v in value]
    if isinstance(value, np.ndarray):
        return serial(value.tolist())
    if isinstance(value, np.generic):
        return serial(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return str(value)
    return value


def save(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(serial(value), indent=2, allow_nan=False) + "\n")
    temporary.replace(path)


def max_relative(actual, expected):
    actual, expected = np.asarray(actual), np.asarray(expected)
    return float(np.max(np.abs(actual - expected) / np.maximum(np.abs(expected), 1e-30)))


def projected_plummer(rng, n, a, q_projected, bounds):
    lo, hi = [r*r/(r*r+a*a) for r in bounds]
    u = rng.uniform(lo, hi, n)
    radii = a * np.sqrt(u/(1-u))
    phi = rng.uniform(0., 2*np.pi, n)
    return radii*np.cos(phi), q_projected*radii*np.sin(phi)


def plummer_los2(radii, mass, a):
    return 3*np.pi*G*mass/(64*a*np.sqrt(1+(radii/a)**2))


def sky_observations(phase, rng, n, inclination, q_projected, bounds, error):
    c, s = np.cos(inclination), np.sin(inclination)
    x, y = phase[:, 0], phase[:, 1]*c-phase[:, 2]*s
    v = phase[:, 4]*s+phase[:, 5]*c
    radius = np.sqrt(x*x+(y/q_projected)**2)
    eligible = np.flatnonzero((radius >= bounds[0]) & (radius <= bounds[1]) &
                              np.isfinite(phase).all(axis=1))
    if len(eligible) < n:
        raise ValueError(f"only {len(eligible)} eligible phase-space points for {n} stars")
    selected = rng.choice(eligible, n, replace=False)
    return dict(x_pc=x[selected], y_pc=y[selected], R_pc=np.hypot(x[selected], y[selected]),
        elliptical_R_pc=radius[selected], vlos_true_kms=v[selected],
        vlos_kms=v[selected]+rng.normal(0., error, n), e_vlos_kms=np.full(n,error),
        pool_indices=selected), len(eligible)


def write_arrays(directory, name, **arrays):
    path = directory / (name + ".npz")
    if path.exists():
        raise FileExistsError(path)
    np.savez_compressed(path, **arrays)
    return dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                shapes={key:list(np.shape(value)) for key,value in arrays.items()})


def spherical_galaxy(agama, protocol):
    case = protocol["spherical"]
    potential = agama.Potential(type="Plummer", mass=case["mass_Msun"]*G/agama.G,
                                scaleRadius=case["rs_pc"])
    density = agama.Density(type="Plummer", mass=1., scaleRadius=case["re_pc"])
    df = agama.DistributionFunction(type="QuasiSpherical", potential=potential, density=density)
    return potential, density, df, agama.GalaxyModel(potential, df)


def spherical_checks(galaxy, protocol):
    c, p = protocol["reference_checks"], protocol["spherical"]
    r = np.asarray(c["radii_pc"])
    points = np.column_stack([r, r*0, r*0])
    density, mean, second = galaxy.moments(points, dens=True, vel=True, vel2=True)
    surface, projected_mean, projected_second = galaxy.moments(points[:,:2], dens=True, vel=True, vel2=True)
    a, mass = p["re_pc"], p["mass_Msun"]
    expected_density = 3/(4*np.pi*a**3)*(1+(r/a)**2)**(-2.5)
    expected_intrinsic = G*mass/(6*a*np.sqrt(1+(r/a)**2))
    expected_projected = plummer_los2(r,mass,a)
    errors = dict(density=max_relative(density,expected_density),
        intrinsic=max_relative(second[:,:3],expected_intrinsic[:,None]),
        projected=max_relative(projected_second[:,2],expected_projected))
    gates = {name: errors[name] <= c[key] for name,key in [
        ("density","max_spherical_df_density_relative_error"),
        ("intrinsic","max_spherical_df_intrinsic_moment_relative_error"),
        ("projected","max_spherical_df_projected_moment_relative_error")]}
    return dict(r_pc=r, density=density, expected_density=expected_density,
        mean_velocity=mean, second_moments=second, expected_sigma_r2=expected_intrinsic,
        surface_density=surface, projected_mean_velocity=projected_mean,
        projected_second_moments=projected_second, expected_sigma_los2=expected_projected,
        max_relative_errors=errors,gates=gates)


def axisymmetric_galaxy(agama, protocol):
    p, c = protocol["axisymmetric"], protocol["reference_checks"]
    halo = agama.Density(type="Spheroid", densityNorm=p["rhos_Msunpc3"]*G/agama.G,
        scaleRadius=p["rs_pc"], axisRatioZ=p["Q"], alpha=p["alpha"], beta=p["beta"], gamma=p["gamma"])
    potential = agama.Potential(type="Multipole", density=halo, **c["agama_multipole"])
    refined = agama.Potential(type="Multipole", density=halo, **c["agama_multipole_refined"])
    tracer = agama.Density(type="Spheroid", mass=1., scaleRadius=p["re_pc"],
        axisRatioZ=p["q"], alpha=2., beta=5., gamma=0.)
    points = np.array(c["force_points_pc"])
    force, reference = potential.force(points), refined.force(points)
    jp = {key:value for key,value in p.items() if key != "vmem_kms"}
    model = AxisymmetricDSphModel(96,96,96)
    dR, dz = model.potential_gradient(points[:,0],points[:,2],params=jp)
    direct = np.column_stack([-dR,points[:,1]*0,-dz])
    refinement = float(np.max(np.linalg.norm(force-reference,axis=1)/np.linalg.norm(reference,axis=1)))
    agreement = float(np.max(np.linalg.norm(force-direct,axis=1)/np.linalg.norm(direct,axis=1)))
    return potential, tracer, dict(points_pc=points, force=force, refined_force=reference,
        jeanspy_force=direct, max_relative_force_refinement=refinement,
        max_relative_force_jeanspy=agreement, gates=dict(
            refinement=refinement <= c["max_agama_force_refinement_relative_norm"],
            jeanspy=agreement <= c["max_agama_jeanspy_force_relative_norm"]))


def tutorials(agama, protocol, output, report, persist):
    obs, sph, axi = protocol["observations"], protocol["spherical"], protocol["axisymmetric"]
    sph_pot, _, _, spherical = spherical_galaxy(agama, protocol)
    report["spherical_df_checks"] = spherical_checks(spherical,protocol)
    persist()
    axis_pot, axis_tracer, report["axisymmetric_force_checks"] = axisymmetric_galaxy(agama,protocol)
    persist()
    for case in protocol["mock_types"]:
        row = dict(id=case["id"], seed=case["seed"], generator=case["generator"], status="running")
        report["mocks"].append(row); persist()
        rng = np.random.default_rng(case["seed"])
        agama.setRandomSeed(case["seed"])
        n, pool_size = obs["n_stars"], obs["phase_space_pool_size"]
        is_spherical = case["id"].startswith("spherical")
        inclination = 0. if is_spherical else axi["inclination"]
        q_projected = 1. if is_spherical else np.sqrt(np.cos(inclination)**2+axi["q"]**2*np.sin(inclination)**2)
        if case["id"].endswith("-gaussian"):
            x,y = projected_plummer(rng,n,sph["re_pc"] if is_spherical else axi["re_pc"],
                                    q_projected,obs["projected_elliptical_radius_pc"])
            if is_spherical:
                variance = plummer_los2(np.hypot(x,y),sph["mass_Msun"],sph["re_pc"])
            else:
                params = {key:value for key,value in axi.items() if key != "vmem_kms"}
                orders = protocol["reference_checks"]["axisymmetric_numpy_orders"]
                predicted = [AxisymmetricDSphModel(order,order,order).sigmalos2(x,y,params=params) for order in orders]
                refinement = max_relative(predicted[-2],predicted[-1])
                row["numerical_reference"] = dict(orders=orders,predictions=predicted,
                    relative_48_64=refinement,gate=refinement <= protocol["reference_checks"]["max_axisymmetric_48_64_value_relative_error"])
                variance = predicted[-1]
            v = rng.normal(0.,np.sqrt(variance))
            data = dict(x_pc=x,y_pc=y,R_pc=np.hypot(x,y),elliptical_R_pc=np.sqrt(x*x+(y/q_projected)**2),
                vlos_true_kms=v,vlos_kms=v+rng.normal(0.,obs["e_vlos_kms"],n),
                e_vlos_kms=np.full(n,obs["e_vlos_kms"]),true_sigma_los2_kms2=variance)
        else:
            if case["id"] == "spherical-agama-df":
                phase, weights = spherical.sample(pool_size)
            elif case["id"] == "axisymmetric-agama-jeans":
                phase, weights = axis_tracer.sample(pool_size,potential=axis_pot,beta=axi["beta_z"],kappa=0.)
            else:
                df = agama.DistributionFunction(**protocol["axisymmetric_df_stress"]["df"])
                phase, weights = agama.GalaxyModel(sph_pot,df).sample(pool_size)
            row["invalid_phase_space_points"] = int(np.count_nonzero(~np.isfinite(phase).all(axis=1)))
            row["phase_space"] = write_arrays(output,case["id"]+"-phase-space",phase_space=phase,mass_weights=weights)
            data, row["eligible_pool_size"] = sky_observations(phase,rng,n,inclination,q_projected,
                obs["projected_elliptical_radius_pc"],obs["e_vlos_kms"])
        row.update(observations=write_arrays(output,case["id"],**data),q_projected=q_projected,
                   status="completed",all_values_finite=all(np.isfinite(v).all() for v in data.values()))
        persist(); print(json.dumps(dict(mock=case["id"],status=row["status"])),flush=True)


def coverage(agama,protocol,output,report,persist):
    config, obs, sph = protocol["conditional_coverage"], protocol["observations"], protocol["spherical"]
    _,_,_,galaxy = spherical_galaxy(agama,protocol)
    report["spherical_df_checks"] = spherical_checks(galaxy,protocol); persist()
    for rep in range(config["repetitions"]):
        seed = config["base_seed"]+rep
        row=dict(rep=rep,agama_seed=seed,status="running"); report["mocks"].append(row); persist()
        agama.setRandomSeed(seed)
        phase, weights = galaxy.sample(config["agama_pool_size_per_repetition"])
        row["invalid_phase_space_points"] = int(np.count_nonzero(~np.isfinite(phase).all(axis=1)))
        rng = np.random.default_rng(seed+1000)
        data, eligible = sky_observations(phase,rng,config["n_stars"],0.,1.,
                                         obs["projected_elliptical_radius_pc"],obs["e_vlos_kms"])
        variance = plummer_los2(data["R_pc"],sph["mass_Msun"],sph["re_pc"])
        data["true_sigma_los2_kms2"] = variance
        control = np.random.default_rng(seed+2000)
        data["gaussian_vlos_kms"] = control.normal(0.,np.sqrt(variance+obs["e_vlos_kms"]**2))
        row.update(status="completed",eligible_pool_size=eligible,
                   observations=write_arrays(output,f"coverage-{rep:03d}",**data))
        persist(); print(json.dumps(dict(rep=rep,status=row["status"])),flush=True)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--agama-path",type=Path,required=True)
    parser.add_argument("--protocol",type=Path,default=ROOT/"validation/release/mock_protocol.json")
    parser.add_argument("--mode",choices=["tutorials","coverage"],required=True)
    parser.add_argument("--output",type=Path,required=True)
    args=parser.parse_args()
    if args.output.exists(): parser.error("output directory already exists; keep previous results")
    args.output.mkdir(parents=True)
    protocol=json.loads(args.protocol.read_text())
    sys.path.insert(0,str(args.agama_path.resolve()))
    import agama
    agama.setUnits(**protocol["units"]["agama_setUnits"])
    report=dict(protocol=protocol,protocol_sha256=hashlib.sha256(args.protocol.read_bytes()).hexdigest(),
        mode=args.mode,status="running",started_utc=datetime.now(timezone.utc).isoformat(),
        python=sys.version,platform=platform.platform(),numpy=np.__version__,argv=sys.argv,
        cpu_affinity=sorted(os.sched_getaffinity(0)),
        git_commit=subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip(),
        runtime_sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                         for p in sorted((ROOT/"src/jeanspy").rglob("*.py"))},
        runner_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        agama_binary=str(agama.__file__),agama_binary_sha256=hashlib.sha256(Path(agama.__file__).read_bytes()).hexdigest(),
        gravity=dict(jeanspy_G=G,agama_G=agama.G,agama_potential_mass_factor=G/agama.G),mocks=[])
    started=time.perf_counter()
    def persist():
        report["elapsed_seconds"]=time.perf_counter()-started
        save(args.output/"manifest.json",report)
    persist()
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        try:
            (tutorials if args.mode=="tutorials" else coverage)(agama,protocol,args.output,report,persist)
            gates=dict(report["spherical_df_checks"]["gates"])
            gates["all_phase_space_points_finite"] = all(row.get("invalid_phase_space_points",0)==0 for row in report["mocks"])
            if "axisymmetric_force_checks" in report:
                gates.update({"force_"+k:v for k,v in report["axisymmetric_force_checks"]["gates"].items()})
                for row in report["mocks"]:
                    if "numerical_reference" in row: gates[row["id"]]=row["numerical_reference"]["gate"]
            report["reference_gates"]=gates
            report["status"]="completed_all_reference_gates_passed" if all(gates.values()) else "completed_with_failed_reference_gates"
        except Exception:
            report.update(status="execution_failed",exception=traceback.format_exc())
            print(report["exception"],flush=True)
        finally:
            report["warnings"]=[dict(category=w.category.__name__,message=str(w.message)) for w in caught]
            report["finished_utc"]=datetime.now(timezone.utc).isoformat(); persist()
    print(json.dumps(dict(status=report["status"],output=str(args.output))),flush=True)
    return 1 if report["status"]=="execution_failed" else 0


if __name__ == "__main__":
    sys.exit(main())
